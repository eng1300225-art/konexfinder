import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  TrendingUp, 
  FileText, 
  Newspaper, 
  MessageSquare, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  Search,
  Sparkles
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { MarketOverview } from './components/MarketOverview';
import { CompanySelector } from './components/CompanySelector';
import { FinancialMetricsView } from './components/FinancialMetricsView';
import { StockChartNaver } from './components/StockChartNaver';
import { NewsSummarySection } from './components/NewsSummarySection';
import { DcGalleryComments } from './components/DcGalleryComments';
import { CompanyTableView } from './components/CompanyTableView';
import { MarketCapRankings } from './components/MarketCapRankings';
import { AddCompanyModal } from './components/AddCompanyModal';
import { INITIAL_KONEX_COMPANIES } from './data/konexData';
import { KonexCompany, AISummaryResult } from './types/konex';

export default function App() {
  const [companies, setCompanies] = useState<KonexCompany[]>(INITIAL_KONEX_COMPANIES);
  const [selectedCode, setSelectedCode] = useState<string>('260870'); // SK시그넷 by default (코넥스 대장주)
  const [activeTab, setActiveTab] = useState<'all' | 'analysis' | 'stocks' | 'news' | 'gallery' | 'rankings'>('analysis');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSector, setSelectedSector] = useState('전체');
  const [sortBy, setSortBy] = useState('marketCap');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Load companies from server
  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        const queryParams = new URLSearchParams();
        if (selectedSector !== '전체') queryParams.append('sector', selectedSector);
        if (searchQuery.trim()) queryParams.append('query', searchQuery.trim());
        if (sortBy) queryParams.append('sort', sortBy);

        const res = await fetch(`/api/companies?${queryParams.toString()}`);
        const data = await res.json();
        if (data.success && data.companies && data.companies.length > 0) {
          setCompanies(data.companies);
        }
      } catch (err) {
        console.warn('Backend fetch failed, using built-in data:', err);
      }
    };
    fetchCompanies();
  }, [selectedSector, searchQuery, sortBy]);

  const selectedCompany = companies.find(c => c.code === selectedCode) || companies[0] || INITIAL_KONEX_COMPANIES[0];

  const handleUpdateSummary = (newSummary: AISummaryResult) => {
    setCompanies(prev =>
      prev.map(c =>
        c.code === selectedCompany.code
          ? { ...c, cachedSummary: newSummary }
          : c
      )
    );
  };

  const handleSelectCompany = (code: string) => {
    setSelectedCode(code);
    if (activeTab === 'all') {
      setActiveTab('analysis');
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col selection:bg-blue-600/30 selection:text-blue-200">
      {/* 1. Header (Navbar adhering to Top Bar Contract) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedCompanyCode={selectedCompany?.code}
        onOpenAddModal={() => setIsAddModalOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Market Overview Macro Strip */}
        <MarketOverview
          companies={companies}
          onSelectCompany={handleSelectCompany}
        />

        {/* Company Quick Selector & Search / Filter */}
        <CompanySelector
          companies={companies}
          selectedCode={selectedCode}
          onSelectCompany={handleSelectCompany}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedSector={selectedSector}
          setSelectedSector={setSelectedSector}
          sortBy={sortBy}
          setSortBy={setSortBy}
        />

        {/* Selected Company Context Hero Strip */}
        {selectedCompany && (
          <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="font-semibold text-blue-400">
                    {selectedCompany.sector}
                  </span>
                  <span>·</span>
                  <span>대표이사: {selectedCompany.ceo}</span>
                  <span>·</span>
                  <span className="font-mono">상장일: {selectedCompany.listingDate}</span>
                </div>

                <div className="flex items-baseline gap-3">
                  <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                    {selectedCompany.name}
                  </h1>
                  <span className="text-sm font-mono text-slate-400">
                    ({selectedCompany.code})
                  </span>
                  <div className="flex items-baseline gap-2 font-mono tabular-nums">
                    <span className="text-lg font-bold text-slate-100">
                      {selectedCompany.quote.currentPrice.toLocaleString()}원
                    </span>
                    <span
                      className={`text-xs font-semibold ${
                        selectedCompany.quote.change >= 0 ? 'text-red-400' : 'text-blue-400'
                      }`}
                    >
                      {selectedCompany.quote.change >= 0 ? '+' : ''}
                      {selectedCompany.quote.changeRate}%
                    </span>
                  </div>
                </div>

                {/* Key Valuation & Shares Summary Strip */}
                <div className="flex flex-wrap items-center gap-3 text-xs font-mono tabular-nums text-slate-300 py-1">
                  <span>시가총액: <strong className="text-slate-100">{selectedCompany.quote.marketCap.toLocaleString()}억원</strong></span>
                  <span className="text-slate-600">·</span>
                  <span>상장주식수: <strong className="text-slate-100">{selectedCompany.quote.sharesOutstanding.toLocaleString()}주</strong></span>
                  <span className="text-slate-600">·</span>
                  <span>
                    EPS: <strong className={selectedCompany.quote.eps >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                      {selectedCompany.quote.eps > 0 ? `+${selectedCompany.quote.eps.toLocaleString()}` : selectedCompany.quote.eps.toLocaleString()}원
                    </strong>
                  </span>
                  <span className="text-slate-600">·</span>
                  <span>
                    PER: <strong className={selectedCompany.quote.per > 0 ? 'text-blue-300' : 'text-slate-400'}>
                      {selectedCompany.quote.per > 0 ? `${selectedCompany.quote.per.toFixed(1)}배` : '적자 (N/A)'}
                    </strong>
                  </span>
                </div>

                <p className="text-xs text-slate-400 max-w-3xl line-clamp-1">
                  주요 사업: {selectedCompany.mainProducts} — {selectedCompany.description}
                </p>
              </div>

              {/* In-Page Section Quick Switcher Tabs */}
              <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg shrink-0">
                <button
                  onClick={() => setActiveTab('rankings')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    activeTab === 'rankings'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                  <span>시총 순위</span>
                </button>
                <button
                  onClick={() => setActiveTab('analysis')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    activeTab === 'analysis'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>DART 6대 지표</span>
                </button>
                <button
                  onClick={() => setActiveTab('stocks')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    activeTab === 'stocks'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5" />
                  <span>네이버 주가/차트</span>
                </button>
                <button
                  onClick={() => setActiveTab('news')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    activeTab === 'news'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>뉴스/AI 요약</span>
                </button>
                <button
                  onClick={() => setActiveTab('gallery')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    activeTab === 'gallery'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>익명 갤러리</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab View Switcher */}
        {activeTab === 'rankings' && (
          <MarketCapRankings
            companies={companies}
            selectedCode={selectedCode}
            onSelectCompany={handleSelectCompany}
          />
        )}

        {activeTab === 'all' && (
          <CompanyTableView
            companies={companies}
            selectedCode={selectedCode}
            onSelectCompany={handleSelectCompany}
          />
        )}

        {activeTab === 'analysis' && selectedCompany && (
          <div className="space-y-6">
            <FinancialMetricsView company={selectedCompany} />
            {/* Contextual Peek to Next Sections */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div 
                onClick={() => setActiveTab('rankings')} 
                className="bg-slate-900/60 border border-slate-800 hover:border-slate-700 p-4 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-semibold text-slate-300">코넥스 시가총액 순위 TOP 확인</h4>
                  <p className="text-[11px] text-slate-500">전체 상장사 시총 랭킹 및 EPS·PER 비교</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
              <div 
                onClick={() => setActiveTab('stocks')} 
                className="bg-slate-900/60 border border-slate-800 hover:border-slate-700 p-4 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-semibold text-slate-300">네이버 증권 주가 &amp; 캔들 차트 바로보기</h4>
                  <p className="text-[11px] text-slate-500">실시간 체결가, 1주일/3개월/1년 추이, 거래량 바 차트</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
              <div 
                onClick={() => setActiveTab('news')} 
                className="bg-slate-900/60 border border-slate-800 hover:border-slate-700 p-4 rounded-xl cursor-pointer transition-colors flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-semibold text-slate-300">최근 뉴스 헤드라인 &amp; AI 핵심 요약</h4>
                  <p className="text-[11px] text-slate-500">최신 언론 보도와 재무 건전성 3줄 리포트 생성</p>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'stocks' && selectedCompany && (
          <div className="space-y-6">
            <StockChartNaver company={selectedCompany} />
            <FinancialMetricsView company={selectedCompany} />
          </div>
        )}

        {activeTab === 'news' && selectedCompany && (
          <div className="space-y-6">
            <NewsSummarySection
              company={selectedCompany}
              onUpdateSummary={handleUpdateSummary}
            />
          </div>
        )}

        {activeTab === 'gallery' && selectedCompany && (
          <div className="space-y-6">
            <DcGalleryComments company={selectedCompany} />
          </div>
        )}
      </main>

      {/* Add Company Modal */}
      <AddCompanyModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onCompanyAdded={(newComp) => {
          setCompanies(prev => [newComp, ...prev]);
          setSelectedCode(newComp.code);
          setActiveTab('analysis');
        }}
      />

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2">
              <span className="font-semibold text-slate-300">KONEX Finder</span>
              <span>·</span>
              <span>대한민국 코넥스 상장 기업 DART 감사보고서 및 네이버 증권 분석 포털</span>
            </div>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 text-slate-400 text-[11px]">
              <span>제작자: <strong className="text-slate-300 font-medium">하준우</strong></span>
              <span>·</span>
              <span>
                문의: <a href="mailto:junwha225@naver.com" className="text-blue-400 hover:text-blue-300 underline underline-offset-2 transition-colors">junwha225@naver.com</a>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-slate-400 text-xs">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="text-blue-400 hover:text-blue-300 font-semibold transition-colors cursor-pointer"
            >
              + 코넥스 기업 등록/관리
            </button>
            <a
              href="https://stock.naver.com/market/stock/kr/konex"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-emerald-400 text-slate-300 transition-colors flex items-center gap-1"
            >
              <span>네이버페이증권 코넥스</span>
              <ExternalLink className="w-3 h-3 text-emerald-400" />
            </a>
            <a
              href="https://konex.krx.co.kr/contents/MKD/04/0406/04060100/MKD04060100.jsp"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-blue-400 text-slate-300 transition-colors flex items-center gap-1"
            >
              <span>KRX 코넥스 상장종목 현황</span>
              <ExternalLink className="w-3 h-3 text-blue-400" />
            </a>
            <a
              href="https://dart.fss.or.kr"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-slate-200 transition-colors"
            >
              금융감독원 DART
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
