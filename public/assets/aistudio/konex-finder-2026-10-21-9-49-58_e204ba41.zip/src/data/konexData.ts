import { KonexCompany, AnonymousComment } from '../types/konex';

export const INITIAL_KONEX_COMPANIES: KonexCompany[] = [
  {
    code: '260870',
    name: 'SK시그넷',
    sector: '전기/모빌리티/제조',
    ceo: '신정호',
    establishedDate: '1998-12-18',
    listingDate: '2017-09-07',
    mainProducts: '초급속 전기차 충전기 (350kW급 이상 V2 초급속기, 메가와트 충전 솔루션)',
    description: '코넥스 시장 대표 시가총액 대장주. 미국 초급속 전기차 충전기 시장 점유율 1위 기업으로 SK그룹 편입 이후 북미 주요 충전사업자(CPO) 대상 공급 확대 및 텍사스 현지 공장 양산 체제를 갖추고 있습니다.',
    dartCorpCode: '01131109',
    currentMetrics: {
      currentRatio: 168.5,      // 유동비율: 168.5% (건전)
      debtRatio: 142.3,         // 부채비율: 142.3% (적정)
      equityRatio: 41.2,        // 자기자본비율: 41.2% (우수, 40% 이상)
      operatingMargin: 4.8,     // 영업이익률: 4.8% (흑자)
      netMargin: 3.2,           // 순이익률: 3.2% (흑자)
      interestCoverage: 2.45,   // 이자보상배율: 2.45배 (안정적 채무상환 가능)
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.20',
        auditor: '안진회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['해외 종속회사(미국법인) 재고자산 평가 및 수익인식', '충전기 보증충당부채 산정의 적정성'],
        metrics: {
          currentRatio: 168.5,
          debtRatio: 142.3,
          equityRatio: 41.2,
          operatingMargin: 4.8,
          netMargin: 3.2,
          interestCoverage: 2.45,
        },
        revenue: 1625.0,
        operatingProfit: 78.0,
        netProfit: 52.0,
        totalAssets: 1840.0,
        totalLiabilities: 1079.0,
        totalEquity: 761.0,
        currentAssets: 1120.0,
        currentLiabilities: 664.7,
        interestExpense: 31.8,
        dartReceiptNo: '20250320000312'
      },
      {
        year: 2023,
        reportName: '2023 사업보고서(감사의견 반영)',
        filingDate: '2024.03.22',
        auditor: '안진회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['초급속 충전기 미국 텍사스 공장 설비투자 감가상각 및 재고자산 진부화'],
        metrics: {
          currentRatio: 154.2,
          debtRatio: 158.0,
          equityRatio: 38.7,
          operatingMargin: 3.6,
          netMargin: 2.1,
          interestCoverage: 1.82,
        },
        revenue: 1480.0,
        operatingProfit: 53.2,
        netProfit: 31.0,
        totalAssets: 1690.0,
        totalLiabilities: 1035.0,
        totalEquity: 655.0,
        currentAssets: 980.0,
        currentLiabilities: 635.5,
        interestExpense: 29.2,
        dartReceiptNo: '20240322000551'
      },
      {
        year: 2022,
        reportName: '2022 감사보고서',
        filingDate: '2023.03.21',
        auditor: '안진회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['미국 수출채권 대손충당금'],
        metrics: {
          currentRatio: 141.0,
          debtRatio: 172.0,
          equityRatio: 36.7,
          operatingMargin: 5.1,
          netMargin: 3.8,
          interestCoverage: 2.10,
        },
        revenue: 1626.0,
        operatingProfit: 82.9,
        netProfit: 61.8,
        totalAssets: 1520.0,
        totalLiabilities: 962.0,
        totalEquity: 558.0,
        currentAssets: 860.0,
        currentLiabilities: 610.0,
        interestExpense: 39.5,
        dartReceiptNo: '20230321000418'
      }
    ],
    quote: {
      currentPrice: 5000,
      change: 120,
      changeRate: 2.46,
      open: 4900,
      high: 5120,
      low: 4850,
      volume: 142800,
      tradingValue: 714,
      marketCap: 1854,
      sharesOutstanding: 37080000,
      foreignRatio: 1.85,
      high52w: 8400,
      low52w: 3950,
      eps: 140,
      per: 35.7,
      bps: 2052,
      pbr: 2.44,
      updatedAt: '2026.10.21 15:30 (네이버페이증권 장마감)'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 4900, high: 4920, low: 4880, close: 4910, volume: 15000 },
        { date: '10:00', open: 4910, high: 5020, low: 4900, close: 4980, volume: 38000 },
        { date: '11:30', open: 4980, high: 5080, low: 4950, close: 5050, volume: 29000 },
        { date: '13:00', open: 5050, high: 5120, low: 5010, close: 5070, volume: 32000 },
        { date: '14:30', open: 5070, high: 5100, low: 4990, close: 5020, volume: 18000 },
        { date: '15:30', open: 5020, high: 5040, low: 4980, close: 5000, volume: 10800 }
      ],
      '1W': [
        { date: '10.15', open: 4750, high: 4860, low: 4700, close: 4820, volume: 85000 },
        { date: '10.16', open: 4820, high: 4950, low: 4800, close: 4880, volume: 110000 },
        { date: '10.17', open: 4880, high: 5000, low: 4850, close: 4920, volume: 98000 },
        { date: '10.18', open: 4920, high: 4980, low: 4850, close: 4880, volume: 76000 },
        { date: '10.21', open: 4900, high: 5120, low: 4850, close: 5000, volume: 142800 }
      ],
      '3M': [
        { date: '08.01', open: 4300, high: 4500, low: 4200, close: 4420, volume: 450000 },
        { date: '08.20', open: 4420, high: 4780, low: 4350, close: 4650, volume: 620000 },
        { date: '09.10', open: 4650, high: 5200, low: 4580, close: 4900, volume: 780000 },
        { date: '09.30', open: 4900, high: 5400, low: 4800, close: 4850, volume: 810000 },
        { date: '10.21', open: 4850, high: 5120, low: 4750, close: 5000, volume: 590000 }
      ],
      '1Y': [
        { date: '2023.11', open: 6200, high: 6800, low: 5800, close: 6100, volume: 1800000 },
        { date: '2024.03', open: 6100, high: 7400, low: 5900, close: 6800, volume: 2400000 },
        { date: '2024.06', open: 6800, high: 8400, low: 5200, close: 5600, volume: 3100000 },
        { date: '2024.10', open: 5600, high: 5800, low: 4300, close: 5000, volume: 1950000 }
      ]
    },
    news: [
      {
        id: 'n-260870-1',
        title: 'SK시그넷, 미국 초급속 충전소 테슬라 NACS 커넥터 표준 장착 본격 공급',
        source: '전자신문',
        date: '2026.10.18',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0005432100&office_id=030&code=260870',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '미국 텍사스 공장에서 생산되는 초급속 충전기에 테슬라 NACS 표준 커넥터를 기본 탑재하여 북미 대형 CPO 공급을 확대한다.'
      },
      {
        id: 'n-260870-2',
        title: 'SK시그넷, 북미 전기트럭용 메가와트(MW)급 차세대 충전 솔루션 개발 완료',
        source: '한국경제',
        date: '2026.10.05',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004910201&office_id=015&code=260870',
        sentiment: 'positive',
        category: '수주/제휴',
        snippet: '대형 물류 트럭을 30분 내 완충하는 1MW급 초고출력 충전기를 공개하며 글로벌 전기 상용차 시장을 선점한다.'
      },
      {
        id: 'n-260870-3',
        title: '코넥스 대장주 SK시그넷, 보통주 공개매수 및 지배구조 개편 추진 보도',
        source: '머니투데이',
        date: '2026.09.28',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004812390&office_id=008&code=260870',
        sentiment: 'neutral',
        category: '자금/공시',
        snippet: 'SK그룹의 지배력 강화 및 주주가치 제고를 위한 공개매수 추진설과 관련하여 공시를 모니터링할 필요가 있다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '코넥스 시가총액 최상위권(1,854억원)을 기록하는 대표 대장주로, 미국 350kW 초급속 전기차 충전 시장 1위 지위를 유지하고 있습니다.',
        'DART 최신 감사보고서상 안진회계법인 감사의견 \'적정\'을 획득하였으며, 유동비율 168.5% 및 부채비율 142.3%로 건전한 재무구조를 보이고 있습니다.',
        '미국 텍사스 현지 공장 본격 가동과 테슬라 NACS 표준 호환 신제품 출시에 따른 북미 CPO 수주 확대로 연간 매출 1,600억원 대를 안정적으로 유지하고 있습니다.'
      ],
      financialHealth: {
        grade: '우수',
        summary: '전기차 캐즘 속에서도 북미 인프라 투자 지속에 힘입어 영업흑자(78억원)를 달성했으며 이자보상배율 2.45배로 채무 이행 능력이 충분합니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (168.5%)', value: '168.5%', status: 'safe', comment: '150% 이상 기준 초과 달성, 단기 지급능력 양호' },
          { metricName: '부채비율 (142.3%)', value: '142.3%', status: 'caution', comment: '설비투자로 100% 상회하나 현금흐름으로 감당 가능' },
          { metricName: '자기자본비율 (41.2%)', value: '41.2%', status: 'safe', comment: '40% 이상 유지로 외부 충격 방어력 확보' },
          { metricName: '영업이익률 (4.8%)', value: '4.8%', status: 'safe', comment: '연간 78억 흑자 시현 중' },
          { metricName: '순이익률 (3.2%)', value: '3.2%', status: 'safe', comment: '당기순익 52억원 흑자' },
          { metricName: '이자보상배율 (2.45배)', value: '2.45배', status: 'safe', comment: '1.5배 이상으로 이자지급 여력 충분' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['미국 NEVI(전기차 인프라 보조금) 정책 수혜 지속', '테슬라 NACS 규격 충전기 본격 인도에 따른 매출 성장'],
        risks: ['전기차 수요 일시적 정체(캐즘)에 따른 충전기 발주 지연 가능성', '글로벌 CPO들의 납품 단가 인하 압력']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '176750',
    name: '듀켐바이오 [코스닥 이전상장]',
    sector: '바이오/제약',
    ceo: '김상우',
    establishedDate: '2002-10-18',
    listingDate: '2014-12-23',
    mainProducts: '방사성의약품(FP-CIT, 뉴라체크, 파킨슨/치매 진단제)',
    description: '국내 1위 방사성의약품 전문기업. 코넥스 상장 이후 지속적인 흑자 경영과 기술 성장을 바탕으로 코스닥 시장으로 성공적인 이전 상장을 완료한 대표 모범 졸업 기업입니다.',
    dartCorpCode: '00895312',
    currentMetrics: {
      currentRatio: 182.4,      // 유동비율: 182.4% (건전)
      debtRatio: 74.2,          // 부채비율: 74.2% (우수, 100% 미만)
      equityRatio: 57.4,        // 자기자본비율: 57.4% (우수, 40% 이상)
      operatingMargin: 15.6,    // 영업이익률: 15.6% (우수)
      netMargin: 11.8,          // 순이익률: 11.8% (우수)
      interestCoverage: 4.85,   // 이자보상배율: 4.85배 (안정적 채무상환 가능)
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.21',
        auditor: '삼일회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['치매 진단제 판매수익 인식의 적정성', '방사성 의약품 제조시설 유형자산 손상평가'],
        metrics: {
          currentRatio: 182.4,
          debtRatio: 74.2,
          equityRatio: 57.4,
          operatingMargin: 15.6,
          netMargin: 11.8,
          interestCoverage: 4.85,
        },
        revenue: 358.4,
        operatingProfit: 55.9,
        netProfit: 42.3,
        totalAssets: 684.2,
        totalLiabilities: 291.5,
        totalEquity: 392.7,
        currentAssets: 341.2,
        currentLiabilities: 187.1,
        interestExpense: 11.5,
        dartReceiptNo: '20250321000842'
      },
      {
        year: 2023,
        reportName: '2023 사업보고서(감사의견 반영)',
        filingDate: '2024.03.20',
        auditor: '삼일회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['전환사채(CB) 파생상품 부채 공정가치 평가'],
        metrics: {
          currentRatio: 165.1,
          debtRatio: 82.5,
          equityRatio: 54.8,
          operatingMargin: 14.1,
          netMargin: 9.7,
          interestCoverage: 3.92,
        },
        revenue: 312.0,
        operatingProfit: 44.0,
        netProfit: 30.3,
        totalAssets: 598.0,
        totalLiabilities: 270.8,
        totalEquity: 327.2,
        currentAssets: 284.0,
        currentLiabilities: 172.0,
        interestExpense: 11.2,
        dartReceiptNo: '20240320000412'
      },
      {
        year: 2022,
        reportName: '2022 사업보고서(감사의견 반영)',
        filingDate: '2023.03.22',
        auditor: '삼일회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['매출채권 대손충당금 설정의 적정성'],
        metrics: {
          currentRatio: 142.0,
          debtRatio: 98.4,
          equityRatio: 50.4,
          operatingMargin: 11.3,
          netMargin: 7.2,
          interestCoverage: 2.75,
        },
        revenue: 265.5,
        operatingProfit: 30.0,
        netProfit: 19.1,
        totalAssets: 512.4,
        totalLiabilities: 254.1,
        totalEquity: 258.3,
        currentAssets: 228.6,
        currentLiabilities: 161.0,
        interestExpense: 10.9,
        dartReceiptNo: '20230322000305'
      }
    ],
    quote: {
      currentPrice: 8450,
      change: 320,
      changeRate: 3.94,
      open: 8150,
      high: 8600,
      low: 8080,
      volume: 184520,
      tradingValue: 1530,
      marketCap: 2195,
      sharesOutstanding: 25976331,
      foreignRatio: 1.24,
      high52w: 9900,
      low52w: 5200,
      eps: 163,
      per: 51.8,
      bps: 1512,
      pbr: 5.59,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 8150, high: 8200, low: 8120, close: 8190, volume: 15200 },
        { date: '10:00', open: 8190, high: 8350, low: 8170, close: 8300, volume: 38400 },
        { date: '11:00', open: 8300, high: 8480, low: 8290, close: 8420, volume: 42100 },
        { date: '12:00', open: 8420, high: 8450, low: 8380, close: 8400, volume: 19800 },
        { date: '13:00', open: 8400, high: 8550, low: 8390, close: 8520, volume: 31200 },
        { date: '14:00', open: 8520, high: 8600, low: 8460, close: 8500, volume: 24500 },
        { date: '15:30', open: 8500, high: 8520, low: 8420, close: 8450, volume: 13320 }
      ],
      '1W': [
        { date: '10.15', open: 7920, high: 8050, low: 7880, close: 8010, volume: 98400 },
        { date: '10.16', open: 8010, high: 8180, low: 7990, close: 8120, volume: 120400 },
        { date: '10.17', open: 8120, high: 8250, low: 8080, close: 8150, volume: 104200 },
        { date: '10.20', open: 8150, high: 8320, low: 8100, close: 8130, volume: 142100 },
        { date: '10.21', open: 8150, high: 8600, low: 8080, close: 8450, volume: 184520 }
      ],
      '3M': [
        { date: '08.01', open: 6900, high: 7150, low: 6850, close: 7080, volume: 420000 },
        { date: '08.15', open: 7080, high: 7350, low: 7000, close: 7280, volume: 560000 },
        { date: '09.01', open: 7300, high: 7700, low: 7250, close: 7650, volume: 890000 },
        { date: '09.15', open: 7650, high: 8100, low: 7550, close: 7980, volume: 720000 },
        { date: '10.01', open: 7980, high: 8350, low: 7850, close: 8100, volume: 640000 },
        { date: '10.21', open: 8100, high: 8600, low: 8080, close: 8450, volume: 810000 }
      ],
      '1Y': [
        { date: '2023.11', open: 5600, high: 6100, low: 5400, close: 5950, volume: 1800000 },
        { date: '2024.01', open: 5950, high: 6700, low: 5800, close: 6400, volume: 2400000 },
        { date: '2024.03', open: 6400, high: 7400, low: 6300, close: 7150, volume: 3800000 },
        { date: '2024.05', open: 7150, high: 7900, low: 7000, close: 7550, volume: 2900000 },
        { date: '2024.07', open: 7550, high: 8300, low: 7400, close: 7800, volume: 3100000 },
        { date: '2024.09', open: 7800, high: 8900, low: 7650, close: 8150, volume: 4200000 },
        { date: '2024.10', open: 8150, high: 9900, low: 8080, close: 8450, volume: 3600000 }
      ]
    },
    news: [
      {
        id: 'n-176750-1',
        title: '듀켐바이오, 치매 조기진단제 레켐비 처방 확대로 사상 최대 실적 기대',
        source: '한국경제',
        date: '2026.10.19',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0005128391&office_id=015&code=176750',
        sentiment: 'positive',
        category: '실적/재무',
        snippet: '국내외 알츠하이머 신약 출시와 함께 PET 진단제 필수 처방이 급증하며 3분기 누적 영업이익이 전년동기 대비 32% 증가했다.'
      },
      {
        id: 'n-176750-2',
        title: '듀켐바이오, 코스닥 이전상장 예비심사 청구서 제출 및 주관사 선정',
        source: '매일경제',
        date: '2026.10.12',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004928114&office_id=009&code=176750',
        sentiment: 'positive',
        category: '자금/공시',
        snippet: '코넥스 대장주 듀켐바이오가 거래소에 코스닥 이전상장 예비심사 신청서를 공식 제출하고 본격적인 IPO 레이스에 돌입했다.'
      },
      {
        id: 'n-176750-3',
        title: '삼일회계법인, 듀켐바이오 최신 감사보고서 \'적정\' 의견 표명',
        source: '머니투데이',
        date: '2026.03.22',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0003847291&office_id=008&code=176750',
        sentiment: 'neutral',
        category: '공시/실적',
        snippet: '부채비율 74%로 코넥스 바이오 기업 중 이례적인 재무안정성을 갖추었으며, 이자보상배율 4.85배로 건전성을 인정받았다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '알츠하이머 치료제(레켐비 등) 국내 보급 가속화로 PET 조기진단 방사성의약품 처방량이 분기 사상 최대치를 경신 중입니다.',
        '코넥스 대장주로서 코스닥 이전상장 예비심사를 청구했으며, 바이오 업종 중 드물게 3년 연속 영업이익 흑자 기조를 확립했습니다.',
        '삼일회계법인 감사결과 \'적정\' 의견이며, 부채비율 74.2% 및 이자보상배율 4.85배로 재무건전성이 최상위 등급에 해당합니다.'
      ],
      financialHealth: {
        grade: '최우수',
        summary: '코넥스 바이오 섹터 내에서 압도적인 재무안정성과 실적 성장을 겸비한 모범 기업입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (182.4%)', value: '182.4%', status: 'safe', comment: '단기 채무 상환능력이 150% 기준선을 훌쩍 상회하여 유동성 리스크가 극히 낮습니다.' },
          { metricName: '부채비율 (74.2%)', value: '74.2%', status: 'safe', comment: '100% 미만으로 코넥스 평균(210%) 대비 매우 건전한 자본구조입니다.' },
          { metricName: '자기자본비율 (57.4%)', value: '57.4%', status: 'safe', comment: '자산 대비 자기자본 비율이 50%를 넘어 외부 충격에 탄탄합니다.' },
          { metricName: '영업이익률 (15.6%)', value: '15.6%', status: 'safe', comment: '제조 원가 경쟁력과 독점적 병원 납품망 덕분에 두 자릿수 고수익률을 기록 중입니다.' },
          { metricName: '순이익률 (11.8%)', value: '11.8%', status: 'safe', comment: '금융비용 부담이 적어 당기순이익 전환율이 높습니다.' },
          { metricName: '이자보상배율 (4.85배)', value: '4.85배', status: 'safe', comment: '영업이익으로 금융 이자를 4.8배 이상 충당할 수 있어 부실 가능성이 없습니다.' }
        ]
      },
      catalystsAndRisks: {
        catalysts: [
          '코스닥 이전상장 심사 통과 시 기관 수급 및 밸류에이션 리레이팅 기대',
          '글로벌 제약사와의 파킨슨/치매 신규 트레이서 국내 독점 위탁 생산 확대'
        ],
        risks: [
          '방사성동위원소 원재료(싸이클로트론 가동) 단가 변동 및 수급 이슈',
          '이전상장 심사 과정에서의 구주매출 비율 및 보호예수 물량 출회 가능성'
        ]
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '246720',
    name: '에스엘에스바이오',
    sector: '바이오/제약',
    ceo: '이영완',
    establishedDate: '2007-01-08',
    listingDate: '2016-06-28',
    mainProducts: '의약품 품질관리 시험, 체외진단용 키트, 백신 검정',
    description: '식약처 공인 의약품 시험검사기관으로 글로벌 제약사의 품질검정 및 신속 진단키트를 개발/수출하는 바이오 분석 전문기업입니다.',
    dartCorpCode: '01129487',
    currentMetrics: {
      currentRatio: 146.5,
      debtRatio: 112.8,
      equityRatio: 47.0,
      operatingMargin: 8.4,
      netMargin: 6.1,
      interestCoverage: 2.14,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 사업보고서(감사의견 반영)',
        filingDate: '2025.03.24',
        auditor: '한영회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['신약 분석 CRO 용역매출의 진행기준 인식', '진단키트 연구개발비 자산화 요건 검토'],
        metrics: {
          currentRatio: 146.5,
          debtRatio: 112.8,
          equityRatio: 47.0,
          operatingMargin: 8.4,
          netMargin: 6.1,
          interestCoverage: 2.14,
        },
        revenue: 168.2,
        operatingProfit: 14.1,
        netProfit: 10.3,
        totalAssets: 320.5,
        totalLiabilities: 170.0,
        totalEquity: 150.5,
        currentAssets: 184.2,
        currentLiabilities: 125.7,
        interestExpense: 6.6,
        dartReceiptNo: '20250324000519'
      },
      {
        year: 2023,
        reportName: '2023 사업보고서(감사의견 반영)',
        filingDate: '2024.03.22',
        auditor: '한영회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['매출채권 대손충당금'],
        metrics: {
          currentRatio: 138.2,
          debtRatio: 125.0,
          equityRatio: 44.4,
          operatingMargin: 6.9,
          netMargin: 4.8,
          interestCoverage: 1.82,
        },
        revenue: 152.0,
        operatingProfit: 10.5,
        netProfit: 7.3,
        totalAssets: 295.0,
        totalLiabilities: 164.0,
        totalEquity: 131.0,
        currentAssets: 162.0,
        currentLiabilities: 117.2,
        interestExpense: 5.8,
        dartReceiptNo: '20240322000388'
      }
    ],
    quote: {
      currentPrice: 4620,
      change: -45,
      changeRate: -0.96,
      open: 4680,
      high: 4750,
      low: 4580,
      volume: 48920,
      tradingValue: 228,
      marketCap: 588,
      sharesOutstanding: 12727272,
      foreignRatio: 0.85,
      high52w: 6100,
      low52w: 3800,
      eps: 81,
      per: 57.0,
      bps: 1182,
      pbr: 3.91,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 4680, high: 4720, low: 4650, close: 4700, volume: 5400 },
        { date: '11:00', open: 4700, high: 4750, low: 4660, close: 4690, volume: 12800 },
        { date: '13:00', open: 4690, high: 4700, low: 4610, close: 4630, volume: 14200 },
        { date: '15:30', open: 4630, high: 4650, low: 4580, close: 4620, volume: 16520 }
      ],
      '1W': [
        { date: '10.15', open: 4750, high: 4820, low: 4680, close: 4700, volume: 38200 },
        { date: '10.16', open: 4700, high: 4740, low: 4650, close: 4680, volume: 29800 },
        { date: '10.17', open: 4680, high: 4710, low: 4620, close: 4650, volume: 32000 },
        { date: '10.20', open: 4650, high: 4690, low: 4600, close: 4665, volume: 41200 },
        { date: '10.21', open: 4680, high: 4750, low: 4580, close: 4620, volume: 48920 }
      ],
      '3M': [
        { date: '08.01', open: 4200, high: 4450, low: 4150, close: 4380, volume: 190000 },
        { date: '08.15', open: 4380, high: 4600, low: 4300, close: 4550, volume: 240000 },
        { date: '09.01', open: 4550, high: 4900, low: 4500, close: 4780, volume: 350000 },
        { date: '09.15', open: 4780, high: 5100, low: 4680, close: 4920, volume: 280000 },
        { date: '10.01', open: 4920, high: 4980, low: 4600, close: 4700, volume: 210000 },
        { date: '10.21', open: 4700, high: 4750, low: 4580, close: 4620, volume: 230000 }
      ],
      '1Y': [
        { date: '2023.11', open: 3950, high: 4300, low: 3800, close: 4100, volume: 850000 },
        { date: '2024.02', open: 4100, high: 4800, low: 4050, close: 4500, volume: 1200000 },
        { date: '2024.05', open: 4500, high: 5500, low: 4400, close: 5100, volume: 1900000 },
        { date: '2024.08', open: 5100, high: 6100, low: 4500, close: 4700, volume: 1600000 },
        { date: '2024.10', open: 4700, high: 4950, low: 4550, close: 4620, volume: 950000 }
      ]
    },
    news: [
      {
        id: 'n-246720-1',
        title: '에스엘에스바이오, 다국적 제약사 항체의약품 품질검사 수주 계약 체결',
        source: '이데일리',
        date: '2026.10.14',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0005118992&office_id=018&code=246720',
        sentiment: 'positive',
        category: '사업제휴',
        snippet: '글로벌 빅파마의 국내 유통 항체 치료제 전 품목에 대한 품질관리 시험 위탁 계약을 연장하며 실적 안정성을 높였다.'
      },
      {
        id: 'n-246720-2',
        title: '에스엘에스바이오, 신속 항원 POCT 키트 유럽 CE 인증 취득',
        source: '디지털타임스',
        date: '2026.09.28',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0003789123&office_id=029&code=246720',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '체외진단 신제품 라인업의 유럽 인허가 완료로 4분기부터 본격적인 해외 수출 물량 출하가 예상된다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '의약품 품질검사 CRO 분야의 탄탄한 기술력으로 다국적 제약사 수주를 꾸준히 확대 중입니다.',
        '2024년 감사보고서 한영회계법인 \'적정\' 의견을 수령했으며, 영업이익률 8.4% 수준을 기록하고 있습니다.',
        '이자보상배율 2.14배로 채무 이행 여력은 안정적이나, 유동비율(146.5%)을 150% 이상으로 제고할 필요가 있습니다.'
      ],
      financialHealth: {
        grade: '양호',
        summary: '매출과 이익이 안정적으로 유지되고 있으며 의약품 시험분야의 경기방어적 성격이 돋보입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (146.5%)', value: '146.5%', status: 'caution', comment: '적정 수준이나 추가적인 운전자본 관리가 권장됩니다.' },
          { metricName: '부채비율 (112.8%)', value: '112.8%', status: 'safe', comment: '100%를 소폭 상회하나 바이오 업종 평균 대비 매우 우량합니다.' },
          { metricName: '자기자본비율 (47.0%)', value: '47.0%', status: 'safe', comment: '안정적인 40% 이상을 유지 중입니다.' },
          { metricName: '영업이익률 (8.4%)', value: '8.4%', status: 'safe', comment: '견조한 흑자 구조를 지속하고 있습니다.' },
          { metricName: '순이익률 (6.1%)', value: '6.1%', status: 'safe', comment: '단기 실적 변동성이 적고 흑자를 지키고 있습니다.' },
          { metricName: '이자보상배율 (2.14배)', value: '2.14배', status: 'safe', comment: '영업이익이 금융비용의 2배 이상으로 이자 연체 우려가 없습니다.' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['유럽 CE 인증 취득에 따른 체외진단 해외 수출 확대', '바이오시밀러 출시 증가로 인한 품질검정 시험 수요 증가'],
        risks: ['국내 의약품 유통 물량 변동 및 식약처 시험 수수료 단가 규제']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '299480',
    name: '지앤이헬스케어',
    sector: '소비재/제조',
    ceo: '장영민',
    establishedDate: '2015-05-18',
    listingDate: '2018-07-26',
    mainProducts: '친환경 유기농 면생리대(한나패드), 여성 헬스케어 위생용품',
    description: '국내 대표 친환경 면생리대 브랜드 \'한나패드(hannahpad)\'를 개발 및 제조하는 펨테크 헬스케어 전문기업입니다. 북미, 일본 등 해외 수출을 확대하고 있습니다.',
    dartCorpCode: '01298413',
    currentMetrics: {
      currentRatio: 122.3,
      debtRatio: 148.6,
      equityRatio: 40.2,
      operatingMargin: 4.2,
      netMargin: 2.1,
      interestCoverage: 1.25,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.25',
        auditor: '대주회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['온라인 직영몰 재고자산 평가 및 반품충당부채'],
        metrics: {
          currentRatio: 122.3,
          debtRatio: 148.6,
          equityRatio: 40.2,
          operatingMargin: 4.2,
          netMargin: 2.1,
          interestCoverage: 1.25,
        },
        revenue: 124.5,
        operatingProfit: 5.2,
        netProfit: 2.6,
        totalAssets: 182.0,
        totalLiabilities: 108.8,
        totalEquity: 73.2,
        currentAssets: 98.4,
        currentLiabilities: 80.5,
        interestExpense: 4.16,
        dartReceiptNo: '20250325000219'
      }
    ],
    quote: {
      currentPrice: 1980,
      change: 60,
      changeRate: 3.12,
      open: 1920,
      high: 2040,
      low: 1910,
      volume: 31200,
      tradingValue: 62,
      marketCap: 154,
      sharesOutstanding: 7777777,
      foreignRatio: 0.12,
      high52w: 2850,
      low52w: 1650,
      eps: 33,
      per: 60.0,
      bps: 941,
      pbr: 2.10,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 1920, high: 1960, low: 1920, close: 1940, volume: 3800 },
        { date: '12:00', open: 1940, high: 1990, low: 1930, close: 1970, volume: 11400 },
        { date: '15:30', open: 1970, high: 2040, low: 1950, close: 1980, volume: 16000 }
      ],
      '1W': [
        { date: '10.15', open: 1910, high: 1950, low: 1890, close: 1920, volume: 22000 },
        { date: '10.16', open: 1920, high: 1940, low: 1900, close: 1910, volume: 18000 },
        { date: '10.17', open: 1910, high: 1930, low: 1890, close: 1900, volume: 15000 },
        { date: '10.20', open: 1900, high: 1940, low: 1895, close: 1920, volume: 24000 },
        { date: '10.21', open: 1920, high: 2040, low: 1910, close: 1980, volume: 31200 }
      ],
      '3M': [
        { date: '08.01', open: 1800, high: 1950, low: 1750, close: 1880, volume: 120000 },
        { date: '08.15', open: 1880, high: 2100, low: 1850, close: 2020, volume: 180000 },
        { date: '09.01', open: 2020, high: 2150, low: 1980, close: 2040, volume: 150000 },
        { date: '09.15', open: 2040, high: 2080, low: 1920, close: 1950, volume: 95000 },
        { date: '10.01', open: 1950, high: 1980, low: 1890, close: 1920, volume: 88000 },
        { date: '10.21', open: 1920, high: 2040, low: 1910, close: 1980, volume: 110000 }
      ],
      '1Y': [
        { date: '2023.11', open: 1700, high: 1900, low: 1650, close: 1820, volume: 450000 },
        { date: '2024.03', open: 1820, high: 2450, low: 1800, close: 2200, volume: 950000 },
        { date: '2024.06', open: 2200, high: 2850, low: 2100, close: 2350, volume: 880000 },
        { date: '2024.10', open: 2350, high: 2400, low: 1900, close: 1980, volume: 520000 }
      ]
    },
    news: [
      {
        id: 'n-299480-1',
        title: '지앤이헬스케어, 일본 돈키호테 입점 완료... K-펨테크 진출 가속화',
        source: '매일경제',
        date: '2026.10.08',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004918234&office_id=009&code=299480',
        sentiment: 'positive',
        category: '사업제휴',
        snippet: '일본 현지 주요 오프라인 드러그스토어 및 잡화점 100개점에 한나패드 단독 입점을 완료하여 해외 판로를 확장했다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '친환경 웰빙 소비 트렌드에 힘입어 일본 및 해외 오프라인 유통 채널 입점이 가시화되고 있습니다.',
        '감사보고서 감사의견 \'적정\'을 유지하고 있으나 원자재 가격 상승으로 영업이익률이 4.2% 수준입니다.',
        '이자보상배율이 1.25배로 1배 기준선 부근에 위치하여 차입금 관리 및 현금창출력 모니터링이 필요합니다.'
      ],
      financialHealth: {
        grade: '주의',
        summary: '흑자를 유지하고 있으나 차입금에 따른 금융비용 부담과 유동비율(122%)에 대한 관리가 필요한 국면입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (122.3%)', value: '122.3%', status: 'caution', comment: '100% 이상이나 150% 미만으로 단기 유동성 주의가 요구됩니다.' },
          { metricName: '부채비율 (148.6%)', value: '148.6%', status: 'caution', comment: '설비 투자로 인한 차입금으로 부채비율이 다소 높습니다.' },
          { metricName: '자기자본비율 (40.2%)', value: '40.2%', status: 'safe', comment: '기준치 40% 수준을 방어하고 있습니다.' },
          { metricName: '영업이익률 (4.2%)', value: '4.2%', status: 'caution', comment: '오프라인 유통 마케팅비 지출로 마진율이 낮습니다.' },
          { metricName: '순이익률 (2.1%)', value: '2.1%', status: 'caution', comment: '금융비용 지출 후 순마진이 얇은 편입니다.' },
          { metricName: '이자보상배율 (1.25배)', value: '1.25배', status: 'caution', comment: '1.0배 이상이나 금리 인상 시 취약해질 수 있는 구간입니다.' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['일본 돈키호테 입점 및 북미 아마존 매출 성장', 'ESG 친환경 위생용품 기업으로서의 브랜드 가치 제고'],
        risks: ['유기농 면화 등 원부자재 가격 변동', '이자보상배율이 1.25배 수준으로 금융비용 상승 시 부담']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '238500',
    name: '로보쓰리에이아이',
    sector: 'IT/로봇/AI',
    ceo: '정성덕',
    establishedDate: '2003-08-20',
    listingDate: '2016-10-04',
    mainProducts: '퍼스널 모빌리티, 물류 이송 로봇, AI 보안 순찰 로봇',
    description: '로봇 제어 기술 및 AI 비전 인식 솔루션을 결합한 지능형 서비스 로봇 및 물류 자동화 로봇 전문 제조기업입니다.',
    dartCorpCode: '01129335',
    currentMetrics: {
      currentRatio: 98.5,       // 100% 미만 위험
      debtRatio: 215.4,         // 200% 초과 위험
      equityRatio: 31.7,
      operatingMargin: -8.5,    // 적자
      netMargin: -12.3,         // 적자
      interestCoverage: -0.85,  // 음수
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.26',
        auditor: '삼덕회계법인',
        opinion: '적정',
        goingConcernIssue: true, // 계속기업 불확실성 기재
        keyAuditPoints: ['계속기업 가정의 불확실성', '개발비 자산 손상평가 및 재고자산 진부화'],
        metrics: {
          currentRatio: 98.5,
          debtRatio: 215.4,
          equityRatio: 31.7,
          operatingMargin: -8.5,
          netMargin: -12.3,
          interestCoverage: -0.85,
        },
        revenue: 85.2,
        operatingProfit: -7.2,
        netProfit: -10.5,
        totalAssets: 145.0,
        totalLiabilities: 99.0,
        totalEquity: 46.0,
        currentAssets: 62.1,
        currentLiabilities: 63.0,
        interestExpense: 8.47,
        dartReceiptNo: '20250326000781'
      }
    ],
    quote: {
      currentPrice: 850,
      change: -25,
      changeRate: -2.86,
      open: 875,
      high: 890,
      low: 840,
      volume: 125000,
      tradingValue: 108,
      marketCap: 128,
      sharesOutstanding: 15058823,
      foreignRatio: 0.05,
      high52w: 1650,
      low52w: 720,
      eps: -70,
      per: -12.1,
      bps: 305,
      pbr: 2.79,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 875, high: 885, low: 860, close: 870, volume: 18000 },
        { date: '11:00', open: 870, high: 890, low: 865, close: 880, volume: 32000 },
        { date: '14:00', open: 880, high: 880, low: 845, close: 850, volume: 45000 },
        { date: '15:30', open: 850, high: 860, low: 840, close: 850, volume: 30000 }
      ],
      '1W': [
        { date: '10.15', open: 920, high: 940, low: 890, close: 900, volume: 110000 },
        { date: '10.16', open: 900, high: 915, low: 880, close: 890, volume: 89000 },
        { date: '10.17', open: 890, high: 900, low: 860, close: 875, volume: 95000 },
        { date: '10.20', open: 875, high: 885, low: 860, close: 875, volume: 82000 },
        { date: '10.21', open: 875, high: 890, low: 840, close: 850, volume: 125000 }
      ],
      '3M': [
        { date: '08.01', open: 1150, high: 1220, low: 1100, close: 1180, volume: 350000 },
        { date: '08.15', open: 1180, high: 1190, low: 1050, close: 1070, volume: 290000 },
        { date: '09.01', open: 1070, high: 1090, low: 950, close: 980, volume: 410000 },
        { date: '09.15', open: 980, high: 1020, low: 920, close: 940, volume: 280000 },
        { date: '10.01', open: 940, high: 950, low: 870, close: 890, volume: 260000 },
        { date: '10.21', open: 890, high: 890, low: 840, close: 850, volume: 310000 }
      ],
      '1Y': [
        { date: '2023.11', open: 1450, high: 1650, low: 1380, close: 1520, volume: 1100000 },
        { date: '2024.02', open: 1520, high: 1550, low: 1250, close: 1320, volume: 850000 },
        { date: '2024.05', open: 1320, high: 1380, low: 1080, close: 1150, volume: 920000 },
        { date: '2024.08', open: 1150, high: 1200, low: 920, close: 960, volume: 870000 },
        { date: '2024.10', open: 960, high: 990, low: 840, close: 850, volume: 760000 }
      ]
    },
    news: [
      {
        id: 'n-238500-1',
        title: '로보쓰리에이아이, 공공기관 AI 방범 순찰 로봇 시범 사업 수주',
        source: '전자신문',
        date: '2026.10.15',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0003021984&office_id=030&code=238500',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '지자체 스마트시티 사업의 일환으로 도심 공원 야간 순찰 AI 로봇 20대를 공급하는 계약을 맺었다.'
      },
      {
        id: 'n-238500-2',
        title: '감사인, 로보쓰리에이아이에 \'계속기업 불확실성\' 강조사항 기재',
        source: '머니투데이',
        date: '2026.03.27',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004918204&office_id=008&code=238500',
        sentiment: 'caution',
        category: '공시/실적',
        snippet: '영업손실 지속 및 단기차입금 만기 도래로 유동비율이 98.5%로 하락해 자금 조달 여부에 주의가 요구된다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        'AI 보안 로봇 및 물류 로봇 분야의 시범 사업 수주 성과는 긍정적이나 R&D 비용 지출이 큽니다.',
        '감사인으로부터 감사의견은 \'적정\'이나 계속기업 불확실성 강조사항이 명시되어 리스크 관리가 시급합니다.',
        '유동비율 98.5%, 부채비율 215.4%, 이자보상배율 음수(-0.85배)로 재무건전성 6개 지표 중 4개가 위험 구간에 진입했습니다.'
      ],
      financialHealth: {
        grade: '취약',
        summary: '영업적자와 높은 부채비율로 인해 유동성 리스크가 상존하며, 유상증자나 전환사채 등 외부 자금 수혈 여부를 주목해야 합니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (98.5%)', value: '98.5%', status: 'danger', comment: '100% 미만으로 단기 부채 상환 시 유동성 압박이 발생할 수 있습니다.' },
          { metricName: '부채비율 (215.4%)', value: '215.4%', status: 'danger', comment: '200%를 초과하여 자기자본 대비 부채 레버리지가 과도합니다.' },
          { metricName: '자기자본비율 (31.7%)', value: '31.7%', status: 'caution', comment: '40% 미만으로 자본 완충력이 다소 낮습니다.' },
          { metricName: '영업이익률 (-8.5%)', value: '-8.5%', status: 'danger', comment: '로봇 개발비 집행 등으로 영업적자가 지속되고 있습니다.' },
          { metricName: '순이익률 (-12.3%)', value: '-12.3%', status: 'danger', comment: '당기순손실로 인해 자기자본이 잠식되고 있습니다.' },
          { metricName: '이자보상배율 (-0.85배)', value: '-0.85배', status: 'danger', comment: '영업이익으로 금융이자를 갚지 못하는 한계기업군 지표입니다.' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['정부의 지능형 로봇 육성 정책 및 공공 실증사업 확대', '대기업 물류센터 PoC 성공 시 양산 계약 전환'],
        risks: ['단기차입금 만기 연장 여부 및 CB 오버행 리스크', '계속기업 존속 불확실성에 따른 투자 유의']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '086150',
    name: '판도라티비',
    sector: '미디어/플랫폼',
    ceo: '김경익',
    establishedDate: '1999-10-29',
    listingDate: '2014-06-27',
    mainProducts: 'KMPlayer 멀티미디어 플레이어, 무비블록(MovieBloc), 디지털 콘텐츠 플랫폼',
    description: '글로벌 8억 다운로드를 기록한 KMPlayer와 독립영화 웹3 스트리밍 플랫폼 무비블록을 운영하는 글로벌 미디어 테크 기업입니다.',
    dartCorpCode: '00371900',
    currentMetrics: {
      currentRatio: 162.8,
      debtRatio: 68.4,
      equityRatio: 59.4,
      operatingMargin: 3.8,
      netMargin: 7.9,
      interestCoverage: 2.80,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.20',
        auditor: '삼일회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['무형자산(콘텐츠 판권 및 소프트웨어) 손상평가', '글로벌 광고수익 인식'],
        metrics: {
          currentRatio: 162.8,
          debtRatio: 68.4,
          equityRatio: 59.4,
          operatingMargin: 3.8,
          netMargin: 7.9,
          interestCoverage: 2.80,
        },
        revenue: 110.5,
        operatingProfit: 4.2,
        netProfit: 8.7,
        totalAssets: 195.0,
        totalLiabilities: 79.2,
        totalEquity: 115.8,
        currentAssets: 112.5,
        currentLiabilities: 69.1,
        interestExpense: 1.5,
        dartReceiptNo: '20250320000318'
      }
    ],
    quote: {
      currentPrice: 1240,
      change: 15,
      changeRate: 1.22,
      open: 1225,
      high: 1260,
      low: 1210,
      volume: 64200,
      tradingValue: 79,
      marketCap: 186,
      sharesOutstanding: 15000000,
      foreignRatio: 0.35,
      high52w: 1980,
      low52w: 1050,
      eps: 58,
      per: 21.4,
      bps: 772,
      pbr: 1.61,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 1225, high: 1240, low: 1220, close: 1230, volume: 8500 },
        { date: '11:00', open: 1230, high: 1255, low: 1225, close: 1250, volume: 21000 },
        { date: '14:00', open: 1250, high: 1260, low: 1235, close: 1240, volume: 22000 },
        { date: '15:30', open: 1240, high: 1245, low: 1230, close: 1240, volume: 12700 }
      ],
      '1W': [
        { date: '10.15', open: 1210, high: 1235, low: 1195, close: 1220, volume: 45000 },
        { date: '10.16', open: 1220, high: 1240, low: 1210, close: 1215, volume: 38000 },
        { date: '10.17', open: 1215, high: 1230, low: 1205, close: 1210, volume: 32000 },
        { date: '10.20', open: 1210, high: 1235, low: 1200, close: 1225, volume: 41000 },
        { date: '10.21', open: 1225, high: 1260, low: 1210, close: 1240, volume: 64200 }
      ],
      '3M': [
        { date: '08.01', open: 1120, high: 1180, low: 1100, close: 1150, volume: 180000 },
        { date: '08.15', open: 1150, high: 1240, low: 1130, close: 1210, volume: 240000 },
        { date: '09.01', open: 1210, high: 1280, low: 1190, close: 1260, volume: 310000 },
        { date: '09.15', open: 1260, high: 1310, low: 1220, close: 1250, volume: 210000 },
        { date: '10.01', open: 1250, high: 1270, low: 1200, close: 1225, volume: 190000 },
        { date: '10.21', open: 1225, high: 1260, low: 1210, close: 1240, volume: 220000 }
      ],
      '1Y': [
        { date: '2023.11', open: 1100, high: 1250, low: 1050, close: 1150, volume: 850000 },
        { date: '2024.03', open: 1150, high: 1550, low: 1120, close: 1420, volume: 1500000 },
        { date: '2024.06', open: 1420, high: 1980, low: 1350, close: 1650, volume: 2200000 },
        { date: '2024.10', open: 1650, high: 1700, low: 1200, close: 1240, volume: 980000 }
      ]
    },
    news: [
      {
        id: 'n-086150-1',
        title: '판도라티비 KMPlayer, AI 자막 번역 및 고화질 업스케일링 기능 탑재',
        source: '지디넷코리아',
        date: '2026.10.11',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0002984124&office_id=092&code=086150',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '생성형 AI 모델을 결합한 30개국어 실시간 자막 번역 서비스로 글로벌 MAU(월간활성이용자)가 2천만명을 재돌파했다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        'KMPlayer의 탄탄한 글로벌 유저베이스에 AI 업스케일링 기술을 접목해 트래픽 반등세를 보이고 있습니다.',
        '감사의견 \'적정\'을 유지하고 있으며 부채비율 68.4%, 유동비율 162.8%로 무차입에 가까운 안정적 재무구조입니다.',
        '이자보상배율 2.80배로 건전하며, 가상자산 및 콘텐츠 판권 가치 평가에 따른 변동성을 유의해야 합니다.'
      ],
      financialHealth: {
        grade: '양호',
        summary: '낮은 부채와 풍부한 유동자산을 바탕으로 탄탄한 재무구조를 구축하고 있습니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (162.8%)', value: '162.8%', status: 'safe', comment: '150% 이상으로 단기 채무 상환능력이 충분합니다.' },
          { metricName: '부채비율 (68.4%)', value: '68.4%', status: 'safe', comment: '100% 미만으로 우수한 재무 건전성입니다.' },
          { metricName: '자기자본비율 (59.4%)', value: '59.4%', status: 'safe', comment: '자산의 60% 가량이 자기자본으로 구성되어 있습니다.' },
          { metricName: '영업이익률 (3.8%)', value: '3.8%', status: 'caution', comment: '광고 단가 하락으로 인해 마진율은 다소 낮습니다.' },
          { metricName: '순이익률 (7.9%)', value: '7.9%', status: 'safe', comment: '투자 지분 및 금융수익 등으로 흑자를 방어했습니다.' },
          { metricName: '이자보상배율 (2.80배)', value: '2.80배', status: 'safe', comment: '금융비용 상환 여력이 충분합니다.' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['AI 비디오 번역 유료 구독 모델 론칭', '무비블록 글로벌 인디 영화제 개최로 플랫폼 수익성 증대'],
        risks: ['온라인 동영상 광고 시장 침체', '글로벌 빅테크(유튜브 등)와의 경쟁 심화']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '200030',
    name: '시냅스엠',
    sector: 'IT/SW',
    ceo: '유병철',
    establishedDate: '2001-11-15',
    listingDate: '2015-07-28',
    mainProducts: '빅데이터 수집/분석 엔진, 소셜 모니터링, AI 데이터 파이프라인',
    description: '공공기관 및 대기업을 대상으로 소셜 빅데이터 수집 솔루션과 인공지능 텍스트 마이닝 플랫폼을 공급하는 엔터프라이즈 SW 기업입니다.',
    dartCorpCode: '00547192',
    currentMetrics: {
      currentRatio: 175.2,
      debtRatio: 45.8,
      equityRatio: 68.6,
      operatingMargin: 12.4,
      netMargin: 10.1,
      interestCoverage: 5.60,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.18',
        auditor: '삼덕회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['SW 구축 용역 수익인식 기준', '연구개발비 무형자산 회수가능액 평가'],
        metrics: {
          currentRatio: 175.2,
          debtRatio: 45.8,
          equityRatio: 68.6,
          operatingMargin: 12.4,
          netMargin: 10.1,
          interestCoverage: 5.60,
        },
        revenue: 98.4,
        operatingProfit: 12.2,
        netProfit: 9.9,
        totalAssets: 158.0,
        totalLiabilities: 49.7,
        totalEquity: 108.3,
        currentAssets: 96.0,
        currentLiabilities: 54.8,
        interestExpense: 2.18,
        dartReceiptNo: '20250318000192'
      }
    ],
    quote: {
      currentPrice: 3450,
      change: 85,
      changeRate: 2.53,
      open: 3380,
      high: 3520,
      low: 3350,
      volume: 24500,
      tradingValue: 84,
      marketCap: 238,
      sharesOutstanding: 6898550,
      foreignRatio: 0.22,
      high52w: 4200,
      low52w: 2600,
      eps: 143,
      per: 24.1,
      bps: 1570,
      pbr: 2.20,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 3380, high: 3420, low: 3360, close: 3400, volume: 4500 },
        { date: '12:00', open: 3400, high: 3480, low: 3390, close: 3460, volume: 11200 },
        { date: '15:30', open: 3460, high: 3520, low: 3430, close: 3450, volume: 8800 }
      ],
      '1W': [
        { date: '10.15', open: 3320, high: 3380, low: 3300, close: 3350, volume: 18000 },
        { date: '10.16', open: 3350, high: 3370, low: 3310, close: 3330, volume: 14000 },
        { date: '10.17', open: 3330, high: 3390, low: 3320, close: 3360, volume: 16000 },
        { date: '10.20', open: 3360, high: 3400, low: 3340, close: 3365, volume: 19000 },
        { date: '10.21', open: 3380, high: 3520, low: 3350, close: 3450, volume: 24500 }
      ],
      '3M': [
        { date: '08.01', open: 2950, high: 3100, low: 2900, close: 3050, volume: 85000 },
        { date: '08.15', open: 3050, high: 3250, low: 3000, close: 3200, volume: 98000 },
        { date: '09.01', open: 3200, high: 3400, low: 3150, close: 3320, volume: 110000 },
        { date: '09.15', open: 3320, high: 3550, low: 3280, close: 3480, volume: 130000 },
        { date: '10.01', open: 3480, high: 3500, low: 3320, close: 3360, volume: 89000 },
        { date: '10.21', open: 3360, high: 3520, low: 3350, close: 3450, volume: 95000 }
      ],
      '1Y': [
        { date: '2023.11', open: 2650, high: 2950, low: 2550, close: 2800, volume: 380000 },
        { date: '2024.03', open: 2800, high: 3400, low: 2750, close: 3150, volume: 550000 },
        { date: '2024.07', open: 3150, high: 4200, low: 3100, close: 3600, volume: 820000 },
        { date: '2024.10', open: 3600, high: 3750, low: 3300, close: 3450, volume: 460000 }
      ]
    },
    news: [
      {
        id: 'n-200030-1',
        title: '시냅스엠, 정부 생성형 AI 거대언어모델(LLM) 데이터 정제 사업 수주',
        source: '디지털타임스',
        date: '2026.10.17',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0003781294&office_id=029&code=200030',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '공공 데이터 학습을 위한 고정밀 데이터 파이프라인 구축 프로젝트의 총괄 사업자로 선정되었다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '공공 및 금융 부문의 AI 데이터 정제 솔루션 수요 폭증으로 두 자릿수 영업이익률(12.4%)을 달성했습니다.',
        '부채비율 45.8%, 자기자본비율 68.6%로 무차입 경영에 가까운 재무적 건전성을 자랑합니다.',
        '이자보상배율 5.60배로 우수하며 감사보고서에서도 \'적정\' 의견을 확보하여 기초체력이 튼튼합니다.'
      ],
      financialHealth: {
        grade: '최우수',
        summary: '소프트웨어 기업 특유의 높은 마진과 탄탄한 자본비율을 바탕으로 코넥스 최우량군에 속합니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (175.2%)', value: '175.2%', status: 'safe', comment: '단기 상환 능력 넉넉함' },
          { metricName: '부채비율 (45.8%)', value: '45.8%', status: 'safe', comment: '50% 미만의 매우 안전한 수준' },
          { metricName: '자기자본비율 (68.6%)', value: '68.6%', status: 'safe', comment: '자산 대부분이 자기자본' },
          { metricName: '영업이익률 (12.4%)', value: '12.4%', status: 'safe', comment: '10% 초과 우량 마진' },
          { metricName: '순이익률 (10.1%)', value: '10.1%', status: 'safe', comment: '순이익 전환율 견고함' },
          { metricName: '이자보상배율 (5.60배)', value: '5.60배', status: 'safe', comment: '이자 상환 능력 탁월함' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['정부 AI 공공사업 예산 배정에 따른 수혜', '자체 LLM 데이터 전처리 SaaS 모델 도입'],
        risks: ['대형 SI 업체와의 입찰 경쟁 심화', '개발 인력 인건비 상승 추세']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '344860',
    name: '이노진',
    sector: '바이오/화장품',
    ceo: '이광훈',
    establishedDate: '2005-05-13',
    listingDate: '2019-11-25',
    mainProducts: '탈모 치료제 및 더마 헤어케어(볼빅 BallVic), 병의원용 기능성 화장품',
    description: '국내 4,000여 개 피부과 및 병의원에 탈모 케어 솔루션 볼빅(BallVic)을 독점 공급하며, 피부 재생 엑소좀 기반 안티에이징 제품을 개발하는 코스메슈티컬 전문기업입니다.',
    dartCorpCode: '01426182',
    currentMetrics: {
      currentRatio: 195.4,
      debtRatio: 52.1,
      equityRatio: 65.7,
      operatingMargin: 16.8,
      netMargin: 13.2,
      interestCoverage: 6.20,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.19',
        auditor: '한영회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['병원 공급 매출의 실재성', '탈모 치료제 연구개발비 계상 적정성'],
        metrics: {
          currentRatio: 195.4,
          debtRatio: 52.1,
          equityRatio: 65.7,
          operatingMargin: 16.8,
          netMargin: 13.2,
          interestCoverage: 6.20,
        },
        revenue: 142.0,
        operatingProfit: 23.9,
        netProfit: 18.7,
        totalAssets: 215.0,
        totalLiabilities: 73.7,
        totalEquity: 141.3,
        currentAssets: 134.8,
        currentLiabilities: 69.0,
        interestExpense: 3.85,
        dartReceiptNo: '20250319000411'
      }
    ],
    quote: {
      currentPrice: 3890,
      change: 140,
      changeRate: 3.73,
      open: 3780,
      high: 3950,
      low: 3750,
      volume: 87500,
      tradingValue: 338,
      marketCap: 468,
      sharesOutstanding: 12030848,
      foreignRatio: 0.64,
      high52w: 4850,
      low52w: 2900,
      eps: 155,
      per: 25.1,
      bps: 1174,
      pbr: 3.31,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 3780, high: 3820, low: 3760, close: 3800, volume: 15000 },
        { date: '11:00', open: 3800, high: 3890, low: 3790, close: 3860, volume: 32000 },
        { date: '14:00', open: 3860, high: 3950, low: 3840, close: 3910, volume: 24000 },
        { date: '15:30', open: 3910, high: 3920, low: 3870, close: 3890, volume: 16500 }
      ],
      '1W': [
        { date: '10.15', open: 3720, high: 3780, low: 3690, close: 3750, volume: 48000 },
        { date: '10.16', open: 3750, high: 3800, low: 3730, close: 3760, volume: 42000 },
        { date: '10.17', open: 3760, high: 3810, low: 3740, close: 3780, volume: 39000 },
        { date: '10.20', open: 3780, high: 3820, low: 3750, close: 3750, volume: 44000 },
        { date: '10.21', open: 3780, high: 3950, low: 3750, close: 3890, volume: 87500 }
      ],
      '3M': [
        { date: '08.01', open: 3200, high: 3450, low: 3150, close: 3400, volume: 210000 },
        { date: '08.15', open: 3400, high: 3650, low: 3350, close: 3580, volume: 280000 },
        { date: '09.01', open: 3580, high: 3800, low: 3500, close: 3720, volume: 340000 },
        { date: '09.15', open: 3720, high: 4100, low: 3680, close: 3980, volume: 420000 },
        { date: '10.01', open: 3980, high: 4050, low: 3700, close: 3780, volume: 290000 },
        { date: '10.21', open: 3780, high: 3950, low: 3750, close: 3890, volume: 380000 }
      ],
      '1Y': [
        { date: '2023.11', open: 3000, high: 3300, low: 2900, close: 3150, volume: 890000 },
        { date: '2024.03', open: 3150, high: 4200, low: 3100, close: 3900, volume: 1800000 },
        { date: '2024.06', open: 3900, high: 4850, low: 3800, close: 4300, volume: 2400000 },
        { date: '2024.10', open: 4300, high: 4400, low: 3600, close: 3890, volume: 1400000 }
      ]
    },
    news: [
      {
        id: 'n-344860-1',
        title: '이노진, 중국 국가약품감독관리국(NMPA) 위생허가 취득 완료',
        source: '한국경제',
        date: '2026.10.16',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0005129941&office_id=015&code=344860',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '대표 탈모 케어 제품군 4종의 중국 인허가가 완료되어 현지 대형 유통사와의 공급 계약 체결이 임박했다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '전국 4,000여 피부과 병의원 채널을 통한 높은 충성도와 브랜드 파워로 영업이익률 16.8%를 기록했습니다.',
        '부채비율 52.1%, 유동비율 195.4%, 이자보상배율 6.20배로 코넥스 상장사 중 최고 수준의 재무 안정성을 갖추었습니다.',
        '중국 NMPA 위생허가 승인에 따른 중화권 및 아시아 신규 시장 진출이 강력한 실적 모멘텀으로 작용할 전망입니다.'
      ],
      financialHealth: {
        grade: '최우수',
        summary: '제약/화장품 업계 평균을 상회하는 안정적 현금 창출력과 무차입에 준하는 자본비율을 유지하고 있습니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (195.4%)', value: '195.4%', status: 'safe', comment: '200%에 근접하는 압도적 단기 지급 능력' },
          { metricName: '부채비율 (52.1%)', value: '52.1%', status: 'safe', comment: '100% 미만으로 극도로 안정적인 부채 구조' },
          { metricName: '자기자본비율 (65.7%)', value: '65.7%', status: 'safe', comment: '외부 충격에 흔들리지 않는 자본 완충력' },
          { metricName: '영업이익률 (16.8%)', value: '16.8%', status: 'safe', comment: '고마진 병의원 공급 구조' },
          { metricName: '순이익률 (13.2%)', value: '13.2%', status: 'safe', comment: '순이익율 10% 이상 최우량' },
          { metricName: '이자보상배율 (6.20배)', value: '6.20배', status: 'safe', comment: '금융비용 상환 능력 완전 여유' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['중국 시장 위생허가 완료 및 면세점 채널 입점 확대', '엑소좀 기반 신약 파이프라인 임상 진입 기대감'],
        risks: ['국내 탈모 샴푸/화장품 시장 경쟁 격화', '병원 유통 수수료 인상 가능성']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '003500',
    name: '티엘엔지니어링',
    sector: '제조/엔지니어링',
    ceo: '박상현',
    establishedDate: '2004-03-12',
    listingDate: '2017-09-15',
    mainProducts: '반도체/이차전지 클린룸 공조 설비, 드라이룸 공학 설계',
    description: '반도체 제조 라인과 이차전지 생산 공정에 필수적인 고청정 클린룸 및 저습도 드라이룸(Dry Room)을 설계/시공하는 첨단 엔지니어링 전문기업입니다.',
    dartCorpCode: '00412891',
    currentMetrics: {
      currentRatio: 135.2,
      debtRatio: 158.4,
      equityRatio: 38.7,
      operatingMargin: 5.1,
      netMargin: 3.4,
      interestCoverage: 1.62,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.27',
        auditor: '안진회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['공사계약 진행기준 매출 인식의 적정성', '공사미수금 손상차손 평가'],
        metrics: {
          currentRatio: 135.2,
          debtRatio: 158.4,
          equityRatio: 38.7,
          operatingMargin: 5.1,
          netMargin: 3.4,
          interestCoverage: 1.62,
        },
        revenue: 412.0,
        operatingProfit: 21.0,
        netProfit: 14.0,
        totalAssets: 480.0,
        totalLiabilities: 294.0,
        totalEquity: 186.0,
        currentAssets: 310.0,
        currentLiabilities: 229.3,
        interestExpense: 12.96,
        dartReceiptNo: '20250327000624'
      }
    ],
    quote: {
      currentPrice: 2280,
      change: -20,
      changeRate: -0.87,
      open: 2310,
      high: 2340,
      low: 2260,
      volume: 38400,
      tradingValue: 88,
      marketCap: 285,
      sharesOutstanding: 12500000,
      foreignRatio: 0.15,
      high52w: 3200,
      low52w: 1950,
      eps: 112,
      per: 20.4,
      bps: 1488,
      pbr: 1.53,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 2310, high: 2330, low: 2290, close: 2300, volume: 5200 },
        { date: '12:00', open: 2300, high: 2340, low: 2280, close: 2310, volume: 16400 },
        { date: '15:30', open: 2310, high: 2310, low: 2260, close: 2280, volume: 16800 }
      ],
      '1W': [
        { date: '10.15', open: 2340, high: 2380, low: 2320, close: 2330, volume: 29000 },
        { date: '10.16', open: 2330, high: 2360, low: 2310, close: 2320, volume: 26000 },
        { date: '10.17', open: 2320, high: 2340, low: 2290, close: 2300, volume: 31000 },
        { date: '10.20', open: 2300, high: 2320, low: 2280, close: 2300, volume: 28000 },
        { date: '10.21', open: 2310, high: 2340, low: 2260, close: 2280, volume: 38400 }
      ],
      '3M': [
        { date: '08.01', open: 2150, high: 2280, low: 2100, close: 2240, volume: 140000 },
        { date: '08.15', open: 2240, high: 2420, low: 2200, close: 2380, volume: 180000 },
        { date: '09.01', open: 2380, high: 2550, low: 2350, close: 2460, volume: 220000 },
        { date: '09.15', open: 2460, high: 2500, low: 2380, close: 2410, volume: 160000 },
        { date: '10.01', open: 2410, high: 2450, low: 2290, close: 2320, volume: 150000 },
        { date: '10.21', open: 2320, high: 2340, low: 2260, close: 2280, volume: 160000 }
      ],
      '1Y': [
        { date: '2023.11', open: 2000, high: 2300, low: 1950, close: 2150, volume: 550000 },
        { date: '2024.03', open: 2150, high: 2800, low: 2100, close: 2550, volume: 920000 },
        { date: '2024.06', open: 2550, high: 3200, low: 2480, close: 2750, volume: 1100000 },
        { date: '2024.10', open: 2750, high: 2800, low: 2250, close: 2280, volume: 680000 }
      ]
    },
    news: [
      {
        id: 'n-003500-1',
        title: '티엘엔지니어링, 북미 배터리 셀 공장 180억원 규모 드라이룸 프로젝트 수주',
        source: '머니투데이',
        date: '2026.10.05',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004901928&office_id=008&code=003500',
        sentiment: 'positive',
        category: '수주/제휴',
        snippet: '이차전지 제조 핵심 공정인 극저노점 드라이룸 공조 설비 시공 계약을 수주하여 하반기 매출 인식이 가속화될 예정이다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '북미 이차전지 기지 투자 재개에 따른 해외 드라이룸 수주 잔고가 400억원을 돌파했습니다.',
        '감사보고서 \'적정\' 의견을 획득했으나, 건설/엔지니어링 업종 특성상 공사미수금 회수 속도가 핵심 변수입니다.',
        '이자보상배율 1.62배로 안전선(1.5배)을 상회하고 있으나 부채비율 158.4%에 대한 지속적 모니터링이 필요합니다.'
      ],
      financialHealth: {
        grade: '양호',
        summary: '수주 기반의 지속적인 매출 성장을 구가하고 있으나 차입금 이자비용 관리가 필요한 국면입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (135.2%)', value: '135.2%', status: 'caution', comment: '100% 이상이나 추가 현금 확보 권장' },
          { metricName: '부채비율 (158.4%)', value: '158.4%', status: 'caution', comment: '100~200% 사이로 공사 이행보증 차입금 영향' },
          { metricName: '자기자본비율 (38.7%)', value: '38.7%', status: 'caution', comment: '40% 기준선에 근접한 수준' },
          { metricName: '영업이익률 (5.1%)', value: '5.1%', status: 'safe', comment: '설비 시공 업계 평균 수준의 흑자 마진' },
          { metricName: '순이익률 (3.4%)', value: '3.4%', status: 'safe', comment: '당기순이익 흑자 기조 유지' },
          { metricName: '이자보상배율 (1.62배)', value: '1.62배', status: 'safe', comment: '1.5배 이상으로 이자부담 감내 가능' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['글로벌 완성차 및 배터리 셀 3사의 신규 공장 증설 재개', '반도체 HBM 패키징 라인 고청정 클린룸 수요 확대'],
        risks: ['전방 산업(전기차 캐즘) 투자 지연 시 수주 취소 위험', '건설 원자재 및 인건비 상승에 따른 원가율 악화']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '265690',
    name: '세중해운',
    sector: '물류/유통',
    ceo: '한명수',
    establishedDate: '1999-03-24',
    listingDate: '2017-12-28',
    mainProducts: '국제해상화물운송, 항공포워딩, 3PL 복합물류',
    description: '미주, 유럽, 동남아 전역을 연결하는 국제 해상/항공 포워딩과 통관, 내륙운송, 보세창고를 일괄 제공하는 종합 물류 선도기업입니다.',
    dartCorpCode: '00358291',
    currentMetrics: {
      currentRatio: 154.0,
      debtRatio: 88.5,
      equityRatio: 53.0,
      operatingMargin: 6.8,
      netMargin: 5.2,
      interestCoverage: 3.40,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.21',
        auditor: '대주회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['해상/항공 운임 정산 및 대손충당금'],
        metrics: {
          currentRatio: 154.0,
          debtRatio: 88.5,
          equityRatio: 53.0,
          operatingMargin: 6.8,
          netMargin: 5.2,
          interestCoverage: 3.40,
        },
        revenue: 380.0,
        operatingProfit: 25.8,
        netProfit: 19.8,
        totalAssets: 340.0,
        totalLiabilities: 159.8,
        totalEquity: 180.2,
        currentAssets: 215.6,
        currentLiabilities: 140.0,
        interestExpense: 7.58,
        dartReceiptNo: '20250321000543'
      }
    ],
    quote: {
      currentPrice: 1580,
      change: 30,
      changeRate: 1.94,
      open: 1550,
      high: 1610,
      low: 1540,
      volume: 42000,
      tradingValue: 66,
      marketCap: 173,
      sharesOutstanding: 10949367,
      foreignRatio: 0.18,
      high52w: 2150,
      low52w: 1350,
      eps: 181,
      per: 8.7,
      bps: 1646,
      pbr: 0.96,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 1550, high: 1570, low: 1540, close: 1560, volume: 6400 },
        { date: '12:00', open: 1560, high: 1610, low: 1550, close: 1590, volume: 18200 },
        { date: '15:30', open: 1590, high: 1600, low: 1570, close: 1580, volume: 17400 }
      ],
      '1W': [
        { date: '10.15', open: 1520, high: 1550, low: 1510, close: 1530, volume: 28000 },
        { date: '10.16', open: 1530, high: 1560, low: 1520, close: 1540, volume: 24000 },
        { date: '10.17', open: 1540, high: 1570, low: 1530, close: 1550, volume: 29000 },
        { date: '10.20', open: 1550, high: 1560, low: 1530, close: 1550, volume: 31000 },
        { date: '10.21', open: 1550, high: 1610, low: 1540, close: 1580, volume: 42000 }
      ],
      '3M': [
        { date: '08.01', open: 1420, high: 1500, low: 1400, close: 1470, volume: 120000 },
        { date: '08.15', open: 1470, high: 1590, low: 1450, close: 1560, volume: 160000 },
        { date: '09.01', open: 1560, high: 1680, low: 1530, close: 1640, volume: 210000 },
        { date: '09.15', open: 1640, high: 1700, low: 1590, close: 1620, volume: 150000 },
        { date: '10.01', open: 1620, high: 1630, low: 1530, close: 1550, volume: 130000 },
        { date: '10.21', open: 1550, high: 1610, low: 1540, close: 1580, volume: 170000 }
      ],
      '1Y': [
        { date: '2023.11', open: 1380, high: 1550, low: 1350, close: 1440, volume: 450000 },
        { date: '2024.03', open: 1440, high: 1850, low: 1420, close: 1720, volume: 880000 },
        { date: '2024.06', open: 1720, high: 2150, low: 1680, close: 1850, volume: 1200000 },
        { date: '2024.10', open: 1850, high: 1900, low: 1520, close: 1580, volume: 640000 }
      ]
    },
    news: [
      {
        id: 'n-265690-1',
        title: '세중해운, 글로벌 해상 운임 반등에 분기 영업이익 전년비 40% 증가',
        source: '한국해운신문',
        date: '2026.10.13',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0002891048&office_id=077&code=265690',
        sentiment: 'positive',
        category: '실적/재무',
        snippet: '홍해 사태 등 글로벌 공급망 우회로 인한 운임 단가 상승이 호실적으로 이어졌다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '글로벌 물류 병목 현상 및 해상 운임 지수 회복으로 안정적인 수수료 마진을 수취하고 있습니다.',
        '부채비율 88.5%, 유동비율 154.0%로 우량한 재무 구조를 보유하고 있으며 배당 여력이 충분합니다.',
        '이자보상배율 3.40배로 견실하며 대주회계법인 감사결과 \'적정\' 의견을 수령했습니다.'
      ],
      financialHealth: {
        grade: '우수',
        summary: '물류 섹터 내에서 매우 모범적인 자본비율과 현금흐름 창출력을 시현 중입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (154.0%)', value: '154.0%', status: 'safe', comment: '150% 이상으로 단기 지급 안정' },
          { metricName: '부채비율 (88.5%)', value: '88.5%', status: 'safe', comment: '100% 미만으로 모범적 수준' },
          { metricName: '자기자본비율 (53.0%)', value: '53.0%', status: 'safe', comment: '자산 대비 자기자본 50% 초과' },
          { metricName: '영업이익률 (6.8%)', value: '6.8%', status: 'safe', comment: '물류 포워딩 업종 평균 대비 양호' },
          { metricName: '순이익률 (5.2%)', value: '5.2%', status: 'safe', comment: '순이익 5% 이상 유지' },
          { metricName: '이자보상배율 (3.40배)', value: '3.40배', status: 'safe', comment: '채무상환 능력 매우 안전' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['연말 쇼핑 시즌 물동량 증가 및 북미 항만 물류 계약 연장', '스마트 물류 자동화 창고 가동에 따른 원가 절감'],
        risks: ['글로벌 경기 둔화에 따른 수출입 컨테이너 물동량 감소', '유가 및 환율 급변동 위험']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '249420',
    name: '루켄테크놀러지스',
    sector: '반도체/장비',
    ceo: '안윤제',
    establishedDate: '2007-06-18',
    listingDate: '2016-12-27',
    mainProducts: '반도체 검사용 M-POGO 핀, 프로브 카드, 검사 소켓',
    description: '반도체 및 디스플레이 후공정 검사 핵심 부품인 초미세 M-POGO 핀과 테스트 소켓을 국산화하여 국내외 메이저 반도체 제조사에 공급하는 하이테크 기업입니다.',
    dartCorpCode: '01183924',
    currentMetrics: {
      currentRatio: 168.4,
      debtRatio: 62.5,
      equityRatio: 61.5,
      operatingMargin: 11.2,
      netMargin: 8.7,
      interestCoverage: 4.10,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.25',
        auditor: '한영회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['초미세 핀 제조설비 감가상각 및 재고자산 평가'],
        metrics: {
          currentRatio: 168.4,
          debtRatio: 62.5,
          equityRatio: 61.5,
          operatingMargin: 11.2,
          netMargin: 8.7,
          interestCoverage: 4.10,
        },
        revenue: 215.0,
        operatingProfit: 24.1,
        netProfit: 18.7,
        totalAssets: 280.0,
        totalLiabilities: 107.7,
        totalEquity: 172.3,
        currentAssets: 178.5,
        currentLiabilities: 106.0,
        interestExpense: 5.88,
        dartReceiptNo: '20250325000418'
      }
    ],
    quote: {
      currentPrice: 4280,
      change: 110,
      changeRate: 2.64,
      open: 4180,
      high: 4350,
      low: 4150,
      volume: 58200,
      tradingValue: 248,
      marketCap: 415,
      sharesOutstanding: 9696261,
      foreignRatio: 0.45,
      high52w: 5600,
      low52w: 3100,
      eps: 193,
      per: 22.2,
      bps: 1777,
      pbr: 2.41,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 4180, high: 4220, low: 4160, close: 4200, volume: 8200 },
        { date: '12:00', open: 4200, high: 4310, low: 4190, close: 4280, volume: 28400 },
        { date: '15:30', open: 4280, high: 4350, low: 4240, close: 4280, volume: 21600 }
      ],
      '1W': [
        { date: '10.15', open: 4100, high: 4180, low: 4050, close: 4120, volume: 34000 },
        { date: '10.16', open: 4120, high: 4160, low: 4080, close: 4100, volume: 29000 },
        { date: '10.17', open: 4100, high: 4170, low: 4090, close: 4140, volume: 38000 },
        { date: '10.20', open: 4140, high: 4220, low: 4120, close: 4170, volume: 42000 },
        { date: '10.21', open: 4180, high: 4350, low: 4150, close: 4280, volume: 58200 }
      ],
      '3M': [
        { date: '08.01', open: 3600, high: 3850, low: 3500, close: 3750, volume: 180000 },
        { date: '08.15', open: 3750, high: 4100, low: 3700, close: 3980, volume: 240000 },
        { date: '09.01', open: 3980, high: 4300, low: 3900, close: 4150, volume: 310000 },
        { date: '09.15', open: 4150, high: 4400, low: 4050, close: 4250, volume: 260000 },
        { date: '10.01', open: 4250, high: 4350, low: 4000, close: 4120, volume: 210000 },
        { date: '10.21', open: 4180, high: 4350, low: 4150, close: 4280, volume: 290000 }
      ],
      '1Y': [
        { date: '2023.11', open: 3200, high: 3600, low: 3100, close: 3400, volume: 750000 },
        { date: '2024.03', open: 3400, high: 4400, low: 3300, close: 4050, volume: 1400000 },
        { date: '2024.06', open: 4050, high: 5600, low: 3900, close: 4700, volume: 2100000 },
        { date: '2024.10', open: 4700, high: 4850, low: 4000, close: 4280, volume: 1200000 }
      ]
    },
    news: [
      {
        id: 'n-249420-1',
        title: '루켄테크놀러지스, AI 반도체 HBM용 초미세 프로브 핀 양산 공급 개시',
        source: '전자신문',
        date: '2026.10.18',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0003028192&office_id=030&code=249420',
        sentiment: 'positive',
        category: '기술/신제품',
        snippet: '고대역폭메모리(HBM) 다층 적층 검사에 최적화된 마이크로 피치 프로브 핀의 국내 종합반도체사 공급을 개시했다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        'AI 반도체 및 고성능 컴퓨팅 수요 증가로 HBM 검사용 초미세 핀 매출 비중이 빠르게 확대되고 있습니다.',
        '부채비율 62.5%, 자기자본비율 61.5%로 매우 탄탄한 자본 건전성을 지니고 있습니다.',
        '이자보상배율 4.10배, 영업이익률 11.2%로 한영회계법인 감사결과 무보류 \'적정\' 의견을 확보했습니다.'
      ],
      financialHealth: {
        grade: '최우수',
        summary: '반도체 소부장 기업 중 최상위 수준의 수익성과 안정성을 두루 갖춘 알짜 코넥스 상장사입니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (168.4%)', value: '168.4%', status: 'safe', comment: '150% 초과로 단기 유동성 우수' },
          { metricName: '부채비율 (62.5%)', value: '62.5%', status: 'safe', comment: '100% 미만 극히 안정적' },
          { metricName: '자기자본비율 (61.5%)', value: '61.5%', status: 'safe', comment: '자산 대비 자기자본 충실' },
          { metricName: '영업이익률 (11.2%)', value: '11.2%', status: 'safe', comment: '두 자릿수 고마진 영업이익' },
          { metricName: '순이익률 (8.7%)', value: '8.7%', status: 'safe', comment: '우량한 순이익 전환율' },
          { metricName: '이자보상배율 (4.10배)', value: '4.10배', status: 'safe', comment: '금융비용 상환 능력 충분' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['HBM 4세대/5세대 검사 소켓 수주 확대', '코스닥 신속이전상장 요건 충족에 따른 이전상장 기대'],
        risks: ['글로벌 반도체 설비투자(CAPEX) 사이클 둔화 시 수주 변동성']
      },
      generatedAt: '2026-10-21 15:30'
    }
  },
  {
    code: '331660',
    name: '한국미라클피플사',
    sector: '소비재/제조',
    ceo: '이호경',
    establishedDate: '2010-04-12',
    listingDate: '2019-10-29',
    mainProducts: '친환경 세제(은나노스텝), 다목적 세정제, K-뷰티 스킨케어',
    description: '홈쇼핑 누적 판매 1,000만 병을 돌파한 국민 다목적 세제 \'은나노스텝\'을 보유한 친환경 위생/생활용품 전문 제조기업입니다.',
    dartCorpCode: '01394821',
    currentMetrics: {
      currentRatio: 142.1,
      debtRatio: 118.0,
      equityRatio: 45.8,
      operatingMargin: 5.6,
      netMargin: 3.9,
      interestCoverage: 2.18,
    },
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.20',
        auditor: '대주회계법인',
        opinion: '적정',
        goingConcernIssue: false,
        keyAuditPoints: ['홈쇼핑 방송 매출 정산 및 반품 충당부채'],
        metrics: {
          currentRatio: 142.1,
          debtRatio: 118.0,
          equityRatio: 45.8,
          operatingMargin: 5.6,
          netMargin: 3.9,
          interestCoverage: 2.18,
        },
        revenue: 185.0,
        operatingProfit: 10.4,
        netProfit: 7.2,
        totalAssets: 210.0,
        totalLiabilities: 113.8,
        totalEquity: 96.2,
        currentAssets: 125.0,
        currentLiabilities: 88.0,
        interestExpense: 4.77,
        dartReceiptNo: '20250320000512'
      }
    ],
    quote: {
      currentPrice: 1720,
      change: -15,
      changeRate: -0.86,
      open: 1740,
      high: 1760,
      low: 1710,
      volume: 18400,
      tradingValue: 32,
      marketCap: 125,
      sharesOutstanding: 7267441,
      foreignRatio: 0.11,
      high52w: 2450,
      low52w: 1450,
      eps: 99,
      per: 17.4,
      bps: 1324,
      pbr: 1.30,
      updatedAt: '2026-10-21 15:30:00'
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: 1740, high: 1750, low: 1720, close: 1730, volume: 3200 },
        { date: '12:00', open: 1730, high: 1760, low: 1725, close: 1740, volume: 7400 },
        { date: '15:30', open: 1740, high: 1745, low: 1710, close: 1720, volume: 7800 }
      ],
      '1W': [
        { date: '10.15', open: 1720, high: 1750, low: 1700, close: 1730, volume: 15000 },
        { date: '10.16', open: 1730, high: 1760, low: 1710, close: 1725, volume: 14000 },
        { date: '10.17', open: 1725, high: 1745, low: 1710, close: 1730, volume: 12000 },
        { date: '10.20', open: 1730, high: 1750, low: 1720, close: 1735, volume: 16000 },
        { date: '10.21', open: 1740, high: 1760, low: 1710, close: 1720, volume: 18400 }
      ],
      '3M': [
        { date: '08.01', open: 1550, high: 1680, low: 1500, close: 1620, volume: 85000 },
        { date: '08.15', open: 1620, high: 1780, low: 1600, close: 1740, volume: 110000 },
        { date: '09.01', open: 1740, high: 1850, low: 1700, close: 1780, volume: 140000 },
        { date: '09.15', open: 1780, high: 1890, low: 1720, close: 1760, volume: 95000 },
        { date: '10.01', open: 1760, high: 1790, low: 1680, close: 1735, volume: 82000 },
        { date: '10.21', open: 1740, high: 1760, low: 1710, close: 1720, volume: 90000 }
      ],
      '1Y': [
        { date: '2023.11', open: 1480, high: 1650, low: 1420, close: 1550, volume: 380000 },
        { date: '2024.03', open: 1550, high: 2100, low: 1520, close: 1850, volume: 820000 },
        { date: '2024.06', open: 1850, high: 2450, low: 1750, close: 1980, volume: 990000 },
        { date: '2024.10', open: 1980, high: 2020, low: 1680, close: 1720, volume: 510000 }
      ]
    },
    news: [
      {
        id: 'n-331660-1',
        title: '한국미라클피플사, 친환경 세제 대만 코스트코 입점 공급 계약',
        source: '매일경제',
        date: '2026.10.12',
        url: 'https://finance.naver.com/item/news_read.naver?article_id=0004919102&office_id=009&code=331660',
        sentiment: 'positive',
        category: '사업제휴',
        snippet: '대만 대형 유통망 공급을 시작으로 동남아 및 중화권 친환경 오프라인 유통 채널을 본격 공략한다.'
      }
    ],
    cachedSummary: {
      corePoints: [
        '스테디셀러 은나노스텝 세제의 안정적인 재구매율과 해외 대형 창고형 매장 수출이 호조세를 보입니다.',
        '감사의견 \'적정\'을 유지 중이며 부채비율 118%, 이자보상배율 2.18배로 건실한 재무 흐름을 보이고 있습니다.',
        '온라인 직영몰 및 B2B 채널 다변화로 홈쇼핑 의존도를 낮추고 이익률 방어에 주력하고 있습니다.'
      ],
      financialHealth: {
        grade: '양호',
        summary: '소비재 분야의 탄탄한 브랜드 인지도를 기반으로 연간 10억원 대의 영업이익 흑자를 지키고 있습니다.',
        metricsEvaluation: [
          { metricName: '유동비율 (142.1%)', value: '142.1%', status: 'caution', comment: '100% 이상이나 운전자본 확충 권장' },
          { metricName: '부채비율 (118.0%)', value: '118.0%', status: 'safe', comment: '제조업 평균 대비 적정' },
          { metricName: '자기자본비율 (45.8%)', value: '45.8%', status: 'safe', comment: '40% 이상 안전선 방어' },
          { metricName: '영업이익률 (5.6%)', value: '5.6%', status: 'safe', comment: '흑자 유지 중' },
          { metricName: '순이익률 (3.9%)', value: '3.9%', status: 'safe', comment: '당기순익 흑자 유지' },
          { metricName: '이자보상배율 (2.18배)', value: '2.18배', status: 'safe', comment: '이자 상환능력 안전' }
        ]
      },
      catalystsAndRisks: {
        catalysts: ['대만 및 동남아 코스트코 등 글로벌 오프라인 유통망 진출', '친환경 바이오 계면활성제 프리미엄 라인 출시'],
        risks: ['홈쇼핑 방송 편성 단가 인상 및 광고 마케팅 비용 증가']
      },
      generatedAt: '2026-10-21 15:30'
    }
  }
];

export const INITIAL_ANONYMOUS_COMMENTS: AnonymousComment[] = [
  {
    id: 'c-201',
    companyCode: '260870',
    category: '호재',
    title: 'SK시그넷 미국 테슬라 NACS 커넥터 장착 소식 떴다!',
    author: '시그넷주주',
    ip: '118.235',
    content: '북미 CPO들이 죄다 테슬라 NACS 규격 요구하고 있는데 시그넷이 발빠르게 V2 초급속기에 기본 탑재 완료했네. 텍사스 공장 가동률 올라가면 내년 매출 2천억 뚫는다 본다.',
    createdAt: '2026-10-21 15:10:15',
    upvotes: 27,
    downvotes: 1,
    views: 450,
    replies: [
      {
        id: 'r-201-1',
        author: '전기차충전개미',
        ip: '223.38',
        content: '인정. 코넥스에서 이 정도 시총(1,800억대)에 북미 1위 실적 찍는 회사는 SK시그넷밖에 없음. 공개매수 썰도 계속 도는데 존버가 답.',
        createdAt: '2026-10-21 15:18:40'
      }
    ]
  },
  {
    id: 'c-202',
    companyCode: '260870',
    category: '분석',
    title: 'SK시그넷 DART 감사보고서 6대 지표 분석 요약',
    author: '재무분석러',
    ip: '175.223',
    content: '유동비율 168.5%로 단기부채 상환 능력 문제 없고, 안진회계법인 적정의견 뜸. 부채비율 142%는 미국 공장 CAPEX 때문이라 영업흑자(78억)로 이자보상배율 2.45배 감당 중.',
    createdAt: '2026-10-21 14:05:00',
    upvotes: 19,
    downvotes: 0,
    views: 388,
    replies: []
  },
  {
    id: 'c-101',
    companyCode: '176750',
    category: '호재',
    title: '듀켐바이오 레켐비 처방 수혜 진짜 제대로 받는 중이다 ㄷㄷ',
    author: 'ㅇㅇ',
    ip: '118.235',
    content: '대학병원 핵의학과 인턴인데 요즘 치매 진단 PET 처방 진짜 미친듯이 나온다. 방사성의약품 반감기 때문에 외국산 수입도 못해서 듀켐바이오 사실상 독점 수준임. 실적보고 깜짝 놀람.',
    createdAt: '2026-10-21 14:15:20',
    upvotes: 18,
    downvotes: 1,
    views: 342,
    replies: [
      {
        id: 'r-101-1',
        author: '코넥스존버',
        ip: '211.36',
        content: '인증 없으면 뭐다? 근데 재무제표 뜯어보니까 부채비율 74%에 이자보상배율 4.8배 찍힌 건 코넥스에선 역대급이긴 함.',
        createdAt: '2026-10-21 14:22:10'
      },
      {
        id: 'r-101-2',
        author: 'ㅇㅇ',
        ip: '118.235',
        content: '병원 사원증 올릴 순 없잖아 ㅋㅋ 코스닥 이전상장 심사만 무사 통과하면 코스닥 바이오 밸류로 날아간다 본다.',
        createdAt: '2026-10-21 14:35:40'
      }
    ]
  },
  {
    id: 'c-102',
    companyCode: '176750',
    category: '분석',
    title: 'DART 최신 감사보고서 6대 지표 뜯어본 후기',
    author: '회계사개미',
    ip: '223.38',
    content: '코넥스 잡주들 태반이 자본잠식에 이자보상배율 마이너스 찍는데, 듀켐은 유동비율 182%에 삼일회계법인 무보류 적정임. CB 오버행만 체크하면 코넥스 대장주 자격 충분함.',
    createdAt: '2026-10-21 12:40:11',
    upvotes: 24,
    downvotes: 2,
    views: 512,
    replies: [
      {
        id: 'r-102-1',
        author: '성지순례',
        ip: '175.223',
        content: '개추 박고 감. 네이버 증권 차트 봐도 3개월 동안 우상향 예쁘게 뚫어놨음.',
        createdAt: '2026-10-21 13:01:45'
      }
    ]
  },
  {
    id: 'c-103',
    companyCode: '238500',
    category: '악재',
    title: '로보쓰리 감사보고서 계속기업 불확실성 떴다 조심해라',
    author: 'ㅇㅇ',
    ip: '121.130',
    content: 'DART 공시 보니까 감사인이 계속기업 불확실성 강조사항 박아놨음. 유동비율 98%에 이자보상배율 음수다. 시범사업 기사 띄우고 유상증자 때릴 확률 99%임.',
    createdAt: '2026-10-21 11:20:05',
    upvotes: 14,
    downvotes: 3,
    views: 290,
    replies: [
      {
        id: 'r-103-1',
        author: '로봇풀매수',
        ip: '58.120',
        content: '로봇 섹터는 기술력이 전부다. 대기업 인수 썰 돌던데 물량 뺏기지 마라.',
        createdAt: '2026-10-21 11:45:00'
      }
    ]
  },
  {
    id: 'c-104',
    companyCode: '344860',
    category: '호재',
    title: '이노진 탈모샴푸 써본 사람 있냐?',
    author: '모발지킴이',
    ip: '182.212',
    content: '피부과에서 처방받아서 볼빅 샴푸 반년째 쓰는 중인데 진짜 굵어짐. 네이버증권 보니 시총 460억밖에 안 하네? 영업이익률 16% 실화냐?',
    createdAt: '2026-10-21 13:50:30',
    upvotes: 11,
    downvotes: 0,
    views: 215,
    replies: []
  }
];
