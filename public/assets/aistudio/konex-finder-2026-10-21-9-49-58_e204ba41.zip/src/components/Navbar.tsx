import React from 'react';
import { ExternalLink, TrendingUp, Search } from 'lucide-react';

interface NavbarProps {
  activeTab: 'analysis' | 'stocks' | 'news' | 'gallery' | 'all' | 'rankings';
  setActiveTab: (tab: 'analysis' | 'stocks' | 'news' | 'gallery' | 'all' | 'rankings') => void;
  selectedCompanyCode: string;
  onOpenAddModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, selectedCompanyCode, onOpenAddModal }) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => setActiveTab('all')}
            className="text-left group flex items-center gap-2.5 focus:outline-none"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:bg-blue-600/30 transition-colors">
              <TrendingUp className="w-4 h-4" />
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-white whitespace-nowrap">
                KONEX Finder
              </span>
              <span className="hidden sm:inline-block text-xs text-slate-400 ml-2 font-normal whitespace-nowrap">
                코넥스 기업분석 &amp; 종목토론
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: 4-5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('rankings')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'rankings'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            시가총액 순위
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'all'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            전체 기업 리스트
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'analysis'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            DART 6대 재무지표
          </button>
          <button
            onClick={() => setActiveTab('stocks')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'stocks'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            네이버증권 주가/차트
          </button>
          <button
            onClick={() => setActiveTab('news')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'news'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            최근뉴스 &amp; AI 요약
          </button>
          <button
            onClick={() => setActiveTab('gallery')}
            className={`whitespace-nowrap shrink-0 transition-colors cursor-pointer py-1 ${
              activeTab === 'gallery'
                ? 'text-blue-400 border-b-2 border-blue-500 font-semibold'
                : 'hover:text-slate-200'
            }`}
          >
            코넥스 갤러리 (익명 토론)
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenAddModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-300 bg-blue-950/50 hover:bg-blue-900/60 border border-blue-800/60 rounded-md transition-colors whitespace-nowrap cursor-pointer"
          >
            <span>+ 기업 등록</span>
          </button>
          <a
            href="https://stock.naver.com/market/stock/kr/konex"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors whitespace-nowrap"
            title="네이버페이증권 코넥스 시장 전체 바로가기"
          >
            <span>네이버페이 코넥스</span>
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
          </a>
          <a
            href={`https://finance.naver.com/item/main.naver?code=${selectedCompanyCode || '260870'}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/40 border border-emerald-800/60 rounded-md hover:bg-emerald-900/50 hover:text-emerald-200 transition-colors whitespace-nowrap"
            title="네이버 증권에서 해당 종목 실시간 시세 조회"
          >
            <span>네이버 시세</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <a
            href="https://dart.fss.or.kr"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-500 transition-colors whitespace-nowrap shadow-sm shadow-blue-500/20"
            title="금융감독원 전자공시시스템 DART 바로가기"
          >
            <span>DART 공시</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
};
