import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { INITIAL_KONEX_COMPANIES, INITIAL_ANONYMOUS_COMMENTS } from './src/data/konexData';
import { KonexCompany, AnonymousComment, AISummaryResult } from './src/types/konex';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// In-memory data store with fallback
let companies: KonexCompany[] = [...INITIAL_KONEX_COMPANIES];
let comments: AnonymousComment[] = [...INITIAL_ANONYMOUS_COMMENTS];

// Gemini AI client
const geminiApiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (geminiApiKey && geminiApiKey !== 'MY_GEMINI_API_KEY') {
  try {
    aiClient = new GoogleGenAI({ apiKey: geminiApiKey });
  } catch (err) {
    console.warn('Gemini AI initialization skipped:', err);
  }
}

// Helper to mask client IP (DC style)
function getMaskedIp(req: Request): string {
  const forwarded = req.headers['x-forwarded-for'];
  let ip = typeof forwarded === 'string' ? forwarded.split(',')[0].trim() : req.socket.remoteAddress || '127.0.0.1';
  if (ip.startsWith('::ffff:')) {
    ip = ip.replace('::ffff:', '');
  }
  if (ip.includes('::1') || ip === '127.0.0.1' || ip.startsWith('10.') || ip.startsWith('192.168.')) {
    // Generate realistic Korean ISP subnet for localhost / cloud proxy
    const subnets = ['118.235', '211.36', '223.38', '175.223', '121.130', '58.120', '182.212', '218.150'];
    return subnets[Math.floor(Math.random() * subnets.length)];
  }
  const parts = ip.split('.');
  if (parts.length >= 2) {
    return `${parts[0]}.${parts[1]}`;
  }
  return '118.235';
}

// -------------------------------------------------------------
// API Routes
// -------------------------------------------------------------

// 1. Get all KONEX companies with summary data
app.get('/api/companies', (req: Request, res: Response) => {
  const { sector, query, sort } = req.query;
  let list = [...companies];

  if (sector && typeof sector === 'string' && sector !== '전체') {
    list = list.filter(c => c.sector.includes(sector));
  }

  if (query && typeof query === 'string' && query.trim() !== '') {
    const q = query.trim().toLowerCase();
    list = list.filter(c => c.name.toLowerCase().includes(q) || c.code.includes(q) || c.mainProducts.toLowerCase().includes(q));
  }

  if (sort && typeof sort === 'string') {
    switch (sort) {
      case 'marketCap':
        list.sort((a, b) => b.quote.marketCap - a.quote.marketCap);
        break;
      case 'changeRate':
        list.sort((a, b) => b.quote.changeRate - a.quote.changeRate);
        break;
      case 'currentRatio':
        list.sort((a, b) => b.currentMetrics.currentRatio - a.currentMetrics.currentRatio);
        break;
      case 'debtRatio':
        list.sort((a, b) => a.currentMetrics.debtRatio - b.currentMetrics.debtRatio);
        break;
      case 'operatingMargin':
        list.sort((a, b) => b.currentMetrics.operatingMargin - a.currentMetrics.operatingMargin);
        break;
      case 'interestCoverage':
        list.sort((a, b) => b.currentMetrics.interestCoverage - a.currentMetrics.interestCoverage);
        break;
      default:
        break;
    }
  }

  res.json({
    success: true,
    count: list.length,
    companies: list
  });
});

// 2. Get single company detail
app.get('/api/companies/:code', (req: Request, res: Response) => {
  const { code } = req.params;
  const company = companies.find(c => c.code === code);
  if (!company) {
    return res.status(404).json({ success: false, message: '해당 코넥스 기업을 찾을 수 없습니다.' });
  }
  res.json({ success: true, company });
});

// 2.1 Add / Register new KONEX company
app.post('/api/companies', (req: Request, res: Response) => {
  const {
    code,
    name,
    sector,
    ceo,
    mainProducts,
    description,
    currentPrice,
    changeRate,
    marketCap,
    currentRatio,
    debtRatio,
    equityRatio,
    operatingMargin,
    netMargin,
    interestCoverage,
    auditor,
    opinion,
    goingConcernIssue,
    revenue,
    operatingProfit,
    netProfit
  } = req.body;

  if (!code || !name) {
    return res.status(400).json({ success: false, message: '종목코드와 기업명은 필수 입력 항목입니다.' });
  }

  const existing = companies.find(c => c.code === code.trim());
  if (existing) {
    return res.status(400).json({ success: false, message: '이미 등록된 코넥스 종목코드입니다.' });
  }

  const parsedPrice = Number(currentPrice) || 2500;
  const parsedChangeRate = Number(changeRate) || 0.0;
  const parsedMarketCap = Number(marketCap) || 200;

  const newMetrics = {
    currentRatio: Number(currentRatio) || 150.0,
    debtRatio: Number(debtRatio) || 85.0,
    equityRatio: Number(equityRatio) || 50.0,
    operatingMargin: Number(operatingMargin) || 7.5,
    netMargin: Number(netMargin) || 5.0,
    interestCoverage: Number(interestCoverage) || 2.5
  };

  const newCompany: KonexCompany = {
    code: code.trim(),
    name: name.trim(),
    sector: sector || 'IT/SW',
    ceo: ceo || '대표이사',
    establishedDate: '2015-01-01',
    listingDate: new Date().toISOString().substring(0, 10),
    mainProducts: mainProducts || '주요 제품 및 서비스',
    description: description || `${name.trim()} 코넥스 상장 기업 DART 감사보고서 분석 종목입니다.`,
    dartCorpCode: '00' + Math.floor(100000 + Math.random() * 900000),
    currentMetrics: newMetrics,
    auditReports: [
      {
        year: 2024,
        reportName: '2024 감사보고서(사업연도)',
        filingDate: '2025.03.20',
        auditor: auditor || '삼일회계법인',
        opinion: opinion || '적정',
        goingConcernIssue: Boolean(goingConcernIssue),
        keyAuditPoints: ['매출채권 대손충당금 및 수익인식'],
        metrics: newMetrics,
        revenue: Number(revenue) || 150.0,
        operatingProfit: Number(operatingProfit) || 12.0,
        netProfit: Number(netProfit) || 8.0,
        totalAssets: 250.0,
        totalLiabilities: 110.0,
        totalEquity: 140.0,
        currentAssets: 150.0,
        currentLiabilities: 100.0,
        interestExpense: 4.8,
        dartReceiptNo: '20250320000' + Math.floor(100 + Math.random() * 900)
      }
    ],
    quote: {
      currentPrice: parsedPrice,
      change: Math.round(parsedPrice * (parsedChangeRate / 100)),
      changeRate: parsedChangeRate,
      open: Math.round(parsedPrice * 0.99),
      high: Math.round(parsedPrice * 1.02),
      low: Math.round(parsedPrice * 0.98),
      volume: 35000,
      tradingValue: Math.round((parsedPrice * 35000) / 1000000),
      marketCap: parsedMarketCap,
      sharesOutstanding: Math.round((parsedMarketCap * 100000000) / parsedPrice),
      foreignRatio: 0.2,
      high52w: Math.round(parsedPrice * 1.3),
      low52w: Math.round(parsedPrice * 0.7),
      eps: Math.round(((Number(netProfit) || 8.0) * 100000000) / Math.max(1, Math.round((parsedMarketCap * 100000000) / parsedPrice))),
      per: Number((parsedPrice / Math.max(1, Math.round(((Number(netProfit) || 8.0) * 100000000) / Math.max(1, Math.round((parsedMarketCap * 100000000) / parsedPrice))))).toFixed(1)),
      bps: Math.round((140.0 * 100000000) / Math.max(1, Math.round((parsedMarketCap * 100000000) / parsedPrice))),
      pbr: Number((parsedPrice / Math.max(1, Math.round((140.0 * 100000000) / Math.max(1, Math.round((parsedMarketCap * 100000000) / parsedPrice))))).toFixed(2)),
      updatedAt: new Date().toISOString().replace('T', ' ').substring(0, 19)
    },
    priceSeries: {
      '1D': [
        { date: '09:00', open: Math.round(parsedPrice * 0.99), high: Math.round(parsedPrice * 1.01), low: Math.round(parsedPrice * 0.98), close: parsedPrice, volume: 5000 },
        { date: '12:00', open: parsedPrice, high: Math.round(parsedPrice * 1.02), low: Math.round(parsedPrice * 0.99), close: parsedPrice, volume: 18000 },
        { date: '15:30', open: parsedPrice, high: Math.round(parsedPrice * 1.01), low: Math.round(parsedPrice * 0.99), close: parsedPrice, volume: 12000 }
      ],
      '1W': [
        { date: '10.15', open: Math.round(parsedPrice * 0.96), high: Math.round(parsedPrice * 0.98), low: Math.round(parsedPrice * 0.95), close: Math.round(parsedPrice * 0.97), volume: 24000 },
        { date: '10.16', open: Math.round(parsedPrice * 0.97), high: Math.round(parsedPrice * 0.99), low: Math.round(parsedPrice * 0.96), close: Math.round(parsedPrice * 0.98), volume: 22000 },
        { date: '10.17', open: Math.round(parsedPrice * 0.98), high: Math.round(parsedPrice * 1.01), low: Math.round(parsedPrice * 0.97), close: Math.round(parsedPrice * 0.99), volume: 28000 },
        { date: '10.20', open: Math.round(parsedPrice * 0.99), high: Math.round(parsedPrice * 1.01), low: Math.round(parsedPrice * 0.98), close: parsedPrice, volume: 31000 },
        { date: '10.21', open: parsedPrice, high: Math.round(parsedPrice * 1.02), low: Math.round(parsedPrice * 0.98), close: parsedPrice, volume: 35000 }
      ],
      '3M': [
        { date: '08.01', open: Math.round(parsedPrice * 0.88), high: Math.round(parsedPrice * 0.92), low: Math.round(parsedPrice * 0.86), close: Math.round(parsedPrice * 0.90), volume: 110000 },
        { date: '08.15', open: Math.round(parsedPrice * 0.90), high: Math.round(parsedPrice * 0.95), low: Math.round(parsedPrice * 0.89), close: Math.round(parsedPrice * 0.93), volume: 140000 },
        { date: '09.01', open: Math.round(parsedPrice * 0.93), high: Math.round(parsedPrice * 0.98), low: Math.round(parsedPrice * 0.92), close: Math.round(parsedPrice * 0.96), volume: 160000 },
        { date: '09.15', open: Math.round(parsedPrice * 0.96), high: Math.round(parsedPrice * 1.02), low: Math.round(parsedPrice * 0.95), close: Math.round(parsedPrice * 0.98), volume: 150000 },
        { date: '10.01', open: Math.round(parsedPrice * 0.98), high: Math.round(parsedPrice * 1.03), low: Math.round(parsedPrice * 0.97), close: parsedPrice, volume: 170000 },
        { date: '10.21', open: parsedPrice, high: Math.round(parsedPrice * 1.03), low: Math.round(parsedPrice * 0.98), close: parsedPrice, volume: 190000 }
      ],
      '1Y': [
        { date: '2023.11', open: Math.round(parsedPrice * 0.8), high: Math.round(parsedPrice * 0.88), low: Math.round(parsedPrice * 0.78), close: Math.round(parsedPrice * 0.85), volume: 450000 },
        { date: '2024.03', open: Math.round(parsedPrice * 0.85), high: Math.round(parsedPrice * 1.1), low: Math.round(parsedPrice * 0.82), close: Math.round(parsedPrice * 0.95), volume: 780000 },
        { date: '2024.06', open: Math.round(parsedPrice * 0.95), high: Math.round(parsedPrice * 1.25), low: Math.round(parsedPrice * 0.92), close: Math.round(parsedPrice * 1.05), volume: 920000 },
        { date: '2024.10', open: Math.round(parsedPrice * 1.05), high: Math.round(parsedPrice * 1.15), low: Math.round(parsedPrice * 0.95), close: parsedPrice, volume: 650000 }
      ]
    },
    news: [
      {
        id: `n-${code.trim()}-1`,
        title: `${name.trim()}, DART 감사보고서 제출 및 코넥스 거래 활성화 기대`,
        source: '한국경제',
        date: new Date().toISOString().substring(0, 10).replace(/-/g, '.'),
        url: `https://finance.naver.com/item/main.naver?code=${code.trim()}`,
        sentiment: 'positive',
        category: '공시/실적',
        snippet: `코넥스 상장 기업 ${name.trim()}이 최신 사업연도 감사보고서 공시를 완료하고 신규 사업 확장을 본격화하고 있다.`
      }
    ]
  };

  companies.push(newCompany);
  res.status(201).json({ success: true, company: newCompany });
});

// 3. AI / Smart Financial & News Core Summary
app.post('/api/companies/:code/summarize', async (req: Request, res: Response) => {
  const { code } = req.params;
  const company = companies.find(c => c.code === code);
  if (!company) {
    return res.status(404).json({ success: false, message: '기업을 찾을 수 없습니다.' });
  }

  // Check if AI generation is possible via Gemini API
  if (aiClient) {
    try {
      const prompt = `
당신은 한국 코스닥/코넥스 전문 최고 수석 재무 애널리스트입니다.
아래 코넥스 상장 기업의 [기본정보], [DART 최신 감사보고서 6대 재무지표], [최근 뉴스 헤드라인]을 정밀 분석하여 투자자를 위한 심층 요약 브리프를 작성하세요.

[기업 정보]
- 기업명: ${company.name} (${company.code})
- 업종: ${company.sector}
- 주요 제품: ${company.mainProducts}
- 시가총액: ${company.quote.marketCap}억원 (현재가: ${company.quote.currentPrice}원, 등락률: ${company.quote.changeRate}%)

[DART 최신 감사보고서 핵심 재무지표 (6개 지표)]
- 유동비율: ${company.currentMetrics.currentRatio}% (기준: 150% 이상 건전)
- 부채비율: ${company.currentMetrics.debtRatio}% (기준: 100% 이하 양호)
- 자기자본비율: ${company.currentMetrics.equityRatio}% (기준: 40% 이상 안전)
- 영업이익률: ${company.currentMetrics.operatingMargin}%
- 순이익률: ${company.currentMetrics.netMargin}%
- 이자보상배율: ${company.currentMetrics.interestCoverage}배 (기준: 1.5배 이상 우수, 1.0배 미만 시 이자 미감당 위험)
- 최신 감사인의견: ${company.auditReports[0]?.opinion || '적정'} (계속기업 불확실성 기재여부: ${company.auditReports[0]?.goingConcernIssue ? '있음(주의)' : '없음'})

[최근 뉴스 헤드라인]
${company.news.map(n => `- [${n.date}] ${n.title} (${n.snippet})`).join('\n')}

반드시 아래 JSON 형식으로만 응답하세요. 백틱이나 마크다운 없이 순수 JSON 문자열만 출력하세요:
{
  "corePoints": ["핵심 요약 1", "핵심 요약 2", "핵심 요약 3"],
  "financialHealth": {
    "grade": "최우수" | "양호" | "주의" | "취약",
    "summary": "재무상태 총평 2~3문장",
    "metricsEvaluation": [
      { "metricName": "유동비율", "value": "${company.currentMetrics.currentRatio}%", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" },
      { "metricName": "부채비율", "value": "${company.currentMetrics.debtRatio}%", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" },
      { "metricName": "자기자본비율", "value": "${company.currentMetrics.equityRatio}%", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" },
      { "metricName": "영업이익률", "value": "${company.currentMetrics.operatingMargin}%", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" },
      { "metricName": "순이익률", "value": "${company.currentMetrics.netMargin}%", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" },
      { "metricName": "이자보상배율", "value": "${company.currentMetrics.interestCoverage}배", "status": "safe" | "caution" | "danger", "comment": "평가 코멘트" }
    ]
  },
  "catalystsAndRisks": {
    "catalysts": ["상승 모멘텀/호재 요인 2가지"],
    "risks": ["투자 시 유의할 리스크 요인 2가지"]
  }
}
`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const responseText = response.text?.trim() || '';
      if (responseText) {
        const parsed = JSON.parse(responseText);
        const result: AISummaryResult = {
          ...parsed,
          generatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
        };
        company.cachedSummary = result;
        return res.json({ success: true, summary: result, isAIGenerated: true });
      }
    } catch (error) {
      console.warn('Gemini API call failed, falling back to rule-based engine:', error);
    }
  }

  // Fallback high-quality rule-based analytical summary
  const m = company.currentMetrics;
  let grade: '최우수' | '우수' | '양호' | '주의' | '취약' = '양호';
  let dangerCount = 0;
  if (m.currentRatio < 100) dangerCount++;
  if (m.debtRatio > 200) dangerCount++;
  if (m.operatingMargin < 0) dangerCount++;
  if (m.interestCoverage < 1.0) dangerCount++;

  if (dangerCount >= 3 || company.auditReports[0]?.goingConcernIssue) {
    grade = '취약';
  } else if (dangerCount >= 1 || m.interestCoverage < 1.5) {
    grade = '주의';
  } else if (m.debtRatio < 100 && m.currentRatio >= 150 && m.interestCoverage >= 3.0 && m.operatingMargin > 10) {
    grade = '최우수';
  }

  const result: AISummaryResult = company.cachedSummary || {
    corePoints: [
      `${company.name}은(는) ${company.sector} 부문에서 ${company.mainProducts}을(를) 영위하고 있습니다.`,
      `DART 최신 감사보고서 기준 감사의견은 '${company.auditReports[0]?.opinion || '적정'}'이며 부채비율 ${m.debtRatio}%, 유동비율 ${m.currentRatio}%입니다.`,
      `이자보상배율은 ${m.interestCoverage}배로 ${m.interestCoverage >= 1.5 ? '영업이익을 통한 이자 지급 여력이 충분합니다.' : '금융이자 상환 부담에 대한 모니터링이 권고됩니다.'}`
    ],
    financialHealth: {
      grade,
      summary: `${company.name}의 6대 재무지표를 종합 분석한 결과 전반적 건전성 등급은 '${grade}' 수준입니다.`,
      metricsEvaluation: [
        {
          metricName: '유동비율',
          value: `${m.currentRatio}%`,
          status: m.currentRatio >= 150 ? 'safe' : m.currentRatio >= 100 ? 'caution' : 'danger',
          comment: m.currentRatio >= 150 ? '단기 유동성 매우 양호' : m.currentRatio >= 100 ? '적정 수준 유지' : '100% 미만으로 단기 지급 주의'
        },
        {
          metricName: '부채비율',
          value: `${m.debtRatio}%`,
          status: m.debtRatio <= 100 ? 'safe' : m.debtRatio <= 200 ? 'caution' : 'danger',
          comment: m.debtRatio <= 100 ? '100% 미만으로 우량' : m.debtRatio <= 200 ? '적정 범위 내 관리 중' : '200% 초과로 과다 레버리지'
        },
        {
          metricName: '자기자본비율',
          value: `${m.equityRatio}%`,
          status: m.equityRatio >= 40 ? 'safe' : m.equityRatio >= 25 ? 'caution' : 'danger',
          comment: m.equityRatio >= 40 ? '자기자본 충실도 높음' : '자본 확충 필요'
        },
        {
          metricName: '영업이익률',
          value: `${m.operatingMargin}%`,
          status: m.operatingMargin >= 10 ? 'safe' : m.operatingMargin >= 0 ? 'caution' : 'danger',
          comment: m.operatingMargin >= 0 ? '영업흑자 달성' : '영업적자 발생 중'
        },
        {
          metricName: '순이익률',
          value: `${m.netMargin}%`,
          status: m.netMargin >= 5 ? 'safe' : m.netMargin >= 0 ? 'caution' : 'danger',
          comment: m.netMargin >= 0 ? '당기순이익 흑자 유지' : '순손실 기록 중'
        },
        {
          metricName: '이자보상배율',
          value: `${m.interestCoverage}배`,
          status: m.interestCoverage >= 1.5 ? 'safe' : m.interestCoverage >= 1.0 ? 'caution' : 'danger',
          comment: m.interestCoverage >= 1.5 ? '이자비용 감당 여유' : '이자보상 1.0배 미만 시 부실위험'
        }
      ]
    },
    catalystsAndRisks: {
      catalysts: [
        '최신 뉴스 및 전방 수주 모멘텀 확대 가능성',
        '코넥스 시장 내 밸류에이션 리레이팅 및 코스닥 이전상장 기대'
      ],
      risks: [
        '코넥스 특유의 거래량 부족 및 환금성 제약',
        '금리 환경 및 전환사채(CB) 오버행 물량 출회 여부'
      ]
    },
    generatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16)
  };

  company.cachedSummary = result;
  res.json({ success: true, summary: result, isAIGenerated: false });
});

// 4. DC-style Anonymous Comments: GET for company
app.get('/api/companies/:code/comments', (req: Request, res: Response) => {
  const { code } = req.params;
  const { filter } = req.query; // 'all' or 'concept' (개념글: upvotes - downvotes >= 3)
  
  let companyComments = comments.filter(c => c.companyCode === code);
  if (filter === 'concept') {
    companyComments = companyComments.filter(c => (c.upvotes - c.downvotes) >= 3);
  }

  // Sort by latest
  companyComments.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json({
    success: true,
    count: companyComments.length,
    comments: companyComments
  });
});

// 5. DC-style Anonymous Comments: POST new comment
app.post('/api/companies/:code/comments', (req: Request, res: Response) => {
  const { code } = req.params;
  const { author, password, category, title, content } = req.body;

  if (!title || !title.trim() || !content || !content.trim()) {
    return res.status(400).json({ success: false, message: '제목과 내용을 모두 입력해주세요.' });
  }

  const clientIp = getMaskedIp(req);
  const newComment: AnonymousComment = {
    id: `c-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    companyCode: code,
    category: category || '일반',
    title: title.trim(),
    author: author?.trim() || 'ㅇㅇ',
    ip: clientIp,
    password: password || '1234',
    content: content.trim(),
    createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    upvotes: 0,
    downvotes: 0,
    views: 1,
    replies: []
  };

  comments.unshift(newComment);
  res.json({ success: true, comment: newComment });
});

// 6. Upvote / Downvote (개념글 추천 / 비추천)
app.post('/api/comments/:id/vote', (req: Request, res: Response) => {
  const { id } = req.params;
  const { type } = req.body; // 'up' or 'down'

  const comment = comments.find(c => c.id === id);
  if (!comment) {
    return res.status(404).json({ success: false, message: '댓글을 찾을 수 없습니다.' });
  }

  if (type === 'up') {
    comment.upvotes += 1;
  } else if (type === 'down') {
    comment.downvotes += 1;
  }

  res.json({
    success: true,
    upvotes: comment.upvotes,
    downvotes: comment.downvotes,
    isConcept: (comment.upvotes - comment.downvotes) >= 3
  });
});

// 7. Add reply to comment
app.post('/api/comments/:id/reply', (req: Request, res: Response) => {
  const { id } = req.params;
  const { author, content, password } = req.body;

  const comment = comments.find(c => c.id === id);
  if (!comment) {
    return res.status(404).json({ success: false, message: '댓글을 찾을 수 없습니다.' });
  }

  if (!content || !content.trim()) {
    return res.status(400).json({ success: false, message: '답글 내용을 입력해주세요.' });
  }

  const clientIp = getMaskedIp(req);
  const newReply = {
    id: `r-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    author: author?.trim() || 'ㅇㅇ',
    ip: clientIp,
    content: content.trim(),
    createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
    passwordHash: password || '1234'
  };

  comment.replies.push(newReply);
  res.json({ success: true, reply: newReply });
});

// 8. Delete comment with password
app.delete('/api/comments/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { password } = req.body;

  const index = comments.findIndex(c => c.id === id);
  if (index === -1) {
    return res.status(404).json({ success: false, message: '댓글을 찾을 수 없습니다.' });
  }

  const comment = comments[index];
  if (comment.password && comment.password !== password) {
    return res.status(403).json({ success: false, message: '비밀번호가 일치하지 않습니다.' });
  }

  comments.splice(index, 1);
  res.json({ success: true, message: '댓글이 성공적으로 삭제되었습니다.' });
});

// -------------------------------------------------------------
// Dev & Production Vite Integration
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    // In dev mode, mount Vite dev server as middleware
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve static files from dist
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`KONEX Finder server running at http://localhost:${PORT} in ${isProd ? 'production' : 'development'} mode`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
